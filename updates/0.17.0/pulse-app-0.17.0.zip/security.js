// Базовая защита «Пульса» для Windows (главный процесс).
//
// 1. Мост к Яндексу и прочие запросы окна принимаются только от страницы самой программы (dist/index.html) —
//    если когда-нибудь окно окажется на чужой странице, она не сможет ничего попросить у главного процесса.
// 2. Окно не уходит со страницы программы: переходы и новые окна запрещены; ссылки наружу открываются в браузере
//    и только на разрешённые сайты (Яндекс, GitHub, LRCLIB) и только по https.
// 3. Все разрешения (микрофон, камера, геолокация, уведомления, экран…) запрещены — программе они не нужны.
// 4. В установленной версии нет меню и сочетаний клавиш для инструментов разработчика (Ctrl+Shift+I, F12, Ctrl+R);
//    открыть их можно только из «Режима разработчика» по паролю.
// 5. Токен Яндекс Музыки хранится зашифрованным средствами Windows (DPAPI через safeStorage): прочитать файл может
//    только ваша учётная запись Windows и только на этом компьютере. В хранилище окна (localStorage) его больше нет.
'use strict';
const { app, ipcMain, session, shell, Menu, safeStorage } = require('electron');
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

const APP_URL = pathToFileURL(path.join(__dirname, 'dist')).href + '/';
const fromApp = (e) => { const u = e && e.senderFrame && e.senderFrame.url; return !!u && u.startsWith(APP_URL); };

// ipcMain.handle, но только для страницы программы
function handle(channel, fn) {
  ipcMain.handle(channel, (e, ...args) => {
    if (!fromApp(e)) { console.log('[security] отклонён запрос', channel, 'от', e && e.senderFrame && e.senderFrame.url); throw new Error('Запрещено'); }
    return fn(e, ...args);
  });
}

// ---------- ссылки наружу ----------
const EXT_HOSTS = ['yandex.ru', 'yandex.com', 'github.com', 'lrclib.net', 'pulsmusic.github.io'];
function safeExternal(url) {
  try {
    const u = new URL(String(url));
    return u.protocol === 'https:' && EXT_HOSTS.some((h) => u.hostname === h || u.hostname.endsWith('.' + h));
  } catch { return false; }
}
function openExternal(url) { if (safeExternal(url)) shell.openExternal(url); else console.log('[security] не открыл ссылку:', String(url).slice(0, 120)); }

// ---------- окно ----------
let devOk = false;   // в этом запуске введён пароль разработчика
function hardenWindow(win) {
  const wc = win.webContents;
  wc.setWindowOpenHandler(({ url }) => { openExternal(url); return { action: 'deny' }; });
  const stay = (e, url) => { if (!String(url).startsWith(APP_URL)) { e.preventDefault(); openExternal(url); } };
  wc.on('will-navigate', stay);
  wc.on('will-redirect', stay);
  wc.on('will-attach-webview', (e) => e.preventDefault());
  if (app.isPackaged) {
    wc.on('devtools-opened', () => { if (!devOk) wc.closeDevTools(); });
    // перезагрузка и инструменты по клавишам — отключены (меню убрано, а F5/Ctrl+R/F12 перехватываем)
    wc.on('before-input-event', (e, i) => {
      const k = String(i.key || '').toLowerCase();
      if (i.type === 'keyDown' && (k === 'f5' || k === 'f12' || ((i.control || i.meta) && (k === 'r' || (i.shift && (k === 'i' || k === 'j' || k === 'c')))))) e.preventDefault();
    });
  }
}

function hardenSession() {
  const s = session.defaultSession;
  const allow = (p) => p === 'fullscreen' || p === 'clipboard-sanitized-write';
  s.setPermissionRequestHandler((_wc, perm, cb) => cb(allow(perm)));
  // проверка «media» — только чтобы видеть названия устройств вывода звука (вкладка «Звук»); сам доступ к микрофону
  // и камере (запрос) по-прежнему запрещён
  s.setPermissionCheckHandler((_wc, perm) => allow(perm) || perm === 'media' || perm === 'speaker-selection');
  s.setDevicePermissionHandler(() => false);
  // на Mac меню оставляем минимальное: без него не работают ⌘Q, ⌘C / ⌘V в полях ввода; пунктов разработчика в нём нет
  if (app.isPackaged) Menu.setApplicationMenu(process.platform === 'darwin' ? Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' }, { role: 'windowMenu' }]) : null);
}

// ---------- токен Яндекс Музыки: зашифрованный файл ----------
// формат: 1 байт (1 — зашифровано DPAPI, 0 — без шифрования, если система его не дала) + данные
const tokFile = () => path.join(app.getPath('userData'), 'secure-token.bin');
function readToken() {
  try {
    const b = fs.readFileSync(tokFile());
    if (b[0] === 1 && safeStorage.isEncryptionAvailable()) return safeStorage.decryptString(b.subarray(1));
    if (b[0] === 0) return b.subarray(1).toString('utf8');
  } catch {}
  return '';
}
function writeToken(t) {
  t = String(t || '').trim().slice(0, 4096);
  const f = tokFile();
  if (!t) { fs.rmSync(f, { force: true }); return; }
  const enc = safeStorage.isEncryptionAvailable();
  const body = enc ? safeStorage.encryptString(t) : Buffer.from(t, 'utf8');
  fs.writeFileSync(f, Buffer.concat([Buffer.from([enc ? 1 : 0]), body]), { mode: 0o600 });
}

function setup() {
  hardenSession();
  ipcMain.on('secret:get', (e) => { e.returnValue = fromApp(e) ? readToken() : ''; });
  handle('secret:set', (_e, t) => { writeToken(t); return { ok: true, encrypted: safeStorage.isEncryptionAvailable() }; });
  handle('dev:devtools', (e) => { if (!devOk) return { ok: false }; e.sender.openDevTools({ mode: 'detach' }); return { ok: true }; });
}

module.exports = { setup, handle, hardenWindow, openExternal, safeExternal, fromApp, setDevOk: (v) => { devOk = !!v; }, isDevOk: () => devOk, APP_URL };
