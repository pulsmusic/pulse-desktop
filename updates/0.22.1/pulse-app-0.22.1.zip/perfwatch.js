// Замер нагрузки при старте трека — только запись в журнал (logs/pulse.log), ничего не меняет и никуда не отправляет.
// Когда плеер начинает новый звук (запрос с начала файла), 8 секунд раз в секунду записываем, сколько процессора
// берёт каждый процесс программы: окно, видеокарта, главный процесс, сеть, звук. По этому журналу видно, кто
// именно даёт всплеск на конкретном компьютере. Не больше 15 стартов за запуск, чтобы журнал не рос.
'use strict';
const { app } = require('electron');
let log = () => {}, busy = false, n = 0, last = '';
const NAME = { Browser: 'главный', Tab: 'окно', GPU: 'видеокарта' };
function kind(m) {
  if (NAME[m.type]) return NAME[m.type];
  const s = String(m.serviceName || m.name || '');
  if (/audio/i.test(s)) return 'звук'; if (/network/i.test(s)) return 'сеть'; if (/storage/i.test(s)) return 'диск';
  return m.type === 'Utility' ? 'служба' : String(m.type || '?').toLowerCase();
}
function snap() {
  const o = {}; let tot = 0;
  for (const m of app.getAppMetrics()) { const v = (m.cpu && m.cpu.percentCPUUsage) || 0; const k = kind(m); o[k] = (o[k] || 0) + v; tot += v; }
  return { o, tot };
}
function kick(what) {
  if (busy || n >= 15 || !app.isReady()) return;
  busy = true; n++; snap();   // первый вызов только «обнуляет» счётчики
  const rows = []; let i = 0;
  const t = setInterval(() => {
    const { o, tot } = snap();
    rows.push(Math.round(tot) + '% (' + Object.entries(o).filter(([, v]) => v >= 1).sort((a, b) => b[1] - a[1]).map(([k, v]) => k + ' ' + Math.round(v)).join(', ') + ')');
    if (++i >= 8) { clearInterval(t); busy = false; const s = rows.join(' → '); if (s !== last) { last = s; log('нагрузка после старта трека (' + what + '), по секундам:', s); } }
  }, 1000);
  t.unref && t.unref();
}
module.exports = { setup(l) { log = l || log; }, kick };
