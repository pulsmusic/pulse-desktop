// Пульс для Windows — главный процесс Electron: окно, запросы к Яндекс Музыке, запоминание размера окна.
'use strict';
const { app, BrowserWindow, ipcMain, shell, nativeTheme, powerMonitor, screen, dialog } = require('electron');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

// ---------- журнал запуска: %APPDATA%\Pulse\logs\pulse.log ----------
// Если «Пульс» не открылся, здесь видно, на каком шаге и почему (его можно прислать разработчику).
const logFile = () => path.join(app.getPath('userData'), 'logs', 'pulse.log');
function log(...a) {
  try {
    const f = logFile(); fs.mkdirSync(path.dirname(f), { recursive: true });
    try { if (fs.statSync(f).size > 512 * 1024) fs.renameSync(f, f + '.old'); } catch {}
    fs.appendFileSync(f, new Date().toISOString() + ' [' + process.pid + '] ' + a.map((x) => (x instanceof Error ? x.stack || x.message : typeof x === 'string' ? x : JSON.stringify(x))).join(' ') + '\n');
  } catch {}
}
process.on('uncaughtException', (e) => { log('ОШИБКА', e); });
process.on('unhandledRejection', (e) => { log('ОШИБКА (promise)', e); });

// Проверка после установки: установщик запускает «Pulse.exe --pulse-selftest <файл>» — программа поднимает
// невидимое окно с интерфейсом, убеждается, что всё загрузилось и отрисовалось, пишет результат и выходит.
const SELFTEST = process.argv.indexOf('--pulse-selftest');
const selftestOut = SELFTEST > 0 ? process.argv[SELFTEST + 1] : '';

// Одна копия программы. Вторая (повторный щелчок по ярлыку) сразу выходит, а первая показывает своё окно.
if (SELFTEST < 0 && !app.requestSingleInstanceLock()) { app.exit(0); }
else {

const ym = require('./yandex');
const upd = require('./updater');
const sec = require('./security');   // базовая защита (см. security.js)
const online = require('./online');   // анонимный счётчик «сейчас онлайн» (см. online.js)
const ai = require('./ai');           // ИИ-разметка живого текста (см. ai.js)
ai.registerScheme();
if (process.platform === 'win32') app.setAppUserModelId('ru.pulse.desktop');

// Что узнали о компьютере в прошлый раз (userData/perf.json): если видеокарта уже падала или Chromium отказался
// от неё, больше не заставляем её работать — старые и «капризные» видеокарты так не мигают и не вылетают.
const perfFile = () => path.join(app.getPath('userData'), 'perf.json');
let memo = {}; try { memo = JSON.parse(fs.readFileSync(perfFile(), 'utf8')) || {}; } catch {}
const saveMemo = () => { try { fs.mkdirSync(path.dirname(perfFile()), { recursive: true }); fs.writeFileSync(perfFile(), JSON.stringify(memo)); } catch {} };
// Безопасный режим: прошлый запуск не дошёл до показа окна (чаще всего — драйвер видеокарты) — теперь без ускорения
// видеокартой. Так «Пульс» открывается, даже если в прошлый раз молча завис.
if (memo.boot === 'start' && SELFTEST < 0) { memo.safe = (memo.safe || 0) + 1; log('прошлый запуск не открыл окно — включаю безопасный режим'); }
const SAFE = !!memo.safe || process.argv.includes('--disable-gpu');
if (SAFE) { app.disableHardwareAcceleration(); }
if (SELFTEST < 0) { memo.boot = 'start'; saveMemo(); }
log('запуск', app.getVersion(), 'Electron', process.versions.electron, os.type(), os.release(), process.arch, SAFE ? 'безопасный режим' : '', SELFTEST > 0 ? 'проверка' : '');
// Плавность на любых мониторах (60 / 120 / 144 / 240 Гц): анимации считает видеокарта.
// Chromium часто «не доверяет» видеокартам ноутбуков и включает программную отрисовку — отсюда ~20 кадров/с.
// Разрешаем видеокарту, только если она ни разу не подвела.
if (!memo.gpuCrash && !SAFE) {
  app.commandLine.appendSwitch('ignore-gpu-blocklist');
  app.commandLine.appendSwitch('enable-gpu-rasterization');
  app.commandLine.appendSwitch('enable-zero-copy');
  app.commandLine.appendSwitch('enable-features', 'CanvasOopRasterization');
}
// видеокарта упала — запоминаем, со следующего запуска работаем со списком «ненадёжных» видеокарт Chromium
app.on('child-process-gone', (_e, d) => { log('процесс завершился', d && d.type, d && d.reason, d && d.exitCode); if (d && d.type === 'GPU' && d.reason !== 'clean-exit' && d.reason !== 'killed') { memo.gpuCrash = (memo.gpuCrash || 0) + 1; saveMemo(); } });
// меньше фоновой работы: проверка орфографии, лишние сетевые службы Chromium программе не нужны
app.commandLine.appendSwitch('disable-features', 'SpareRendererForSitePerProcess,MediaRouter');
app.commandLine.appendSwitch('disable-background-networking');

// ---------- какой компьютер: встроенная / виртуальная видеокарта, MacBook с Windows, работа от батареи ----------
// По этому интерфейс сам выбирает «облегчённые эффекты» (их можно включить или выключить вручную в профиле).
const perf = { tier: 'normal', reasons: [], gpu: '', mac: false, ram: 0, cores: 0, weak: false };
const VENDORS = { 0x8086: 'Intel', 0x1002: 'AMD', 0x10de: 'NVIDIA', 0x1414: 'Microsoft', 0x1ab8: 'Parallels', 0x15ad: 'VMware', 0x80ee: 'VirtualBox', 0x106b: 'Apple', 0x5143: 'Qualcomm' };
async function detectPerf() {
  try {
    const g = await app.getGPUInfo('basic');
    const devs = (g && g.gpuDevice) || []; const act = devs.find((d) => d.active) || devs[0] || {};
    perf.gpu = VENDORS[act.vendorId] || '';
    if (perf.gpu === 'Intel' || perf.gpu === 'Qualcomm') perf.reasons.push('встроенная видеокарта ' + perf.gpu);
    if (['Microsoft', 'Parallels', 'VMware', 'VirtualBox'].includes(perf.gpu)) perf.reasons.push('виртуальная видеокарта (' + perf.gpu + ')');
  } catch {}
  try { const fsx = app.getGPUFeatureStatus(); if (fsx && String(fsx.gpu_compositing || '').startsWith('disabled')) perf.reasons.push('нет ускорения видеокартой'); } catch {}
  if (process.platform === 'win32') {
    await new Promise((res) => execFile('powershell.exe', ['-NoProfile', '-Command', '(Get-CimInstance Win32_ComputerSystem).Manufacturer'], { timeout: 5000, windowsHide: true }, (e, out) => {
      if (!e && /apple/i.test(String(out))) { perf.mac = true; perf.reasons.push('MacBook с Windows'); }
      res();
    }));
  }
  // память и процессор: 4 ГБ и меньше или 2–4 потока — это старый ноутбук/офисный ПК
  perf.ram = Math.round(os.totalmem() / 1073741824); perf.cores = (os.cpus() || []).length;
  if (perf.ram && perf.ram <= 4) perf.reasons.push('мало памяти (' + perf.ram + ' ГБ)');
  if (perf.cores && perf.cores <= 4) perf.reasons.push('процессор на ' + perf.cores + ' потока');
  if (SAFE) perf.reasons.push('безопасный режим (без видеокарты)');
  if (memo.gpuCrash) perf.reasons.push('видеокарта уже давала сбой');
  if (memo.slow) perf.reasons.push('интерфейс шёл медленно в прошлый раз');
  perf.weak = (perf.ram && perf.ram <= 4) || (perf.cores && perf.cores <= 2) || perf.reasons.includes('нет ускорения видеокартой');
  perf.tier = perf.reasons.length ? 'lite' : 'normal';
  return perf;
}
const perfReady = app.whenReady().then(detectPerf);
// интерфейс сам заметил, что кадров мало (или наоборот, всё плавно) — запоминаем на следующий запуск
// «Включить видеокарту снова» в профиле: снимаем безопасный режим, со следующего запуска — снова с видеокартой
sec.handle('perf:unsafe', () => { memo.safe = 0; memo.gpuCrash = 0; memo.slow = false; saveMemo(); return true; });
sec.handle('perf:relaunch', () => { app.relaunch(); app.exit(0); });
sec.handle('perf:log', () => logFile());
// живой фон плеера: можно ли «послушать» звук трека (разрешает ли сервер Яндекса чтение звука странице — CORS).
// Если нет — звук не трогаем вовсе (иначе он стал бы беззвучным), фон просто плавно движется.
sec.handle('audio:cors', async (_e, url) => {
  try {
    const u = new URL(String(url)); if (u.protocol !== 'https:' || !/(^|\.)yandex\.(net|ru)$/.test(u.hostname)) return false;
    const r = await fetch(u.href, { headers: { Origin: 'null', Range: 'bytes=0-1' }, redirect: 'follow', signal: AbortSignal.timeout(6000) });
    const ok = r.headers.get('access-control-allow-origin') === '*';
    try { r.body && r.body.cancel(); } catch {}
    return ok;
  } catch { return false; }
});
// полноэкранный режим: F11 или кнопка; окно сообщает интерфейсу, когда режим меняется
sec.handle('win:fs', (_e, v) => { if (!win) return false; win.setFullScreen(v == null ? !win.isFullScreen() : !!v); return win.isFullScreen(); });
// живой текст: время каждого слова (своё, из общей базы или посчитанное ИИ в фоне — см. ai.js)
ai.setup({ log, notify: (id) => { if (win && !win.isDestroyed()) win.webContents.send('ai:done', id); } });
sec.handle('ai:times', (_e, q) => ai.times(q).catch((e) => { log('ИИ', e && e.message); return { ok: false }; }));
sec.handle('ai:state', () => ai.state());
sec.handle('perf:slow', (_e, v) => { memo.slow = !!v; saveMemo(); return true; });
sec.handle('perf', async () => { await perfReady; let battery = false; try { battery = powerMonitor.isOnBatteryPower(); } catch {} return { ...perf, battery, safe: SAFE, gpuCrash: !!memo.gpuCrash }; });

const stateFile = () => path.join(app.getPath('userData'), 'window.json');
const loadState = () => { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch { return {}; } };

// Размер и место окна: прошлые — только если окно целиком помещается на одном из экранов (после смены монитора,
// масштаба или отключения второго экрана окно иначе открывалось бы за краем и казалось, что программа не запустилась).
function bounds() {
  const st = loadState(); const wa = screen.getPrimaryDisplay().workArea;
  const w0 = Math.min(1440, wa.width), h0 = Math.min(900, wa.height);
  const def = { width: w0, height: h0, x: Math.round(wa.x + (wa.width - w0) / 2), y: Math.round(wa.y + (wa.height - h0) / 2), max: false };
  if (!(st.w > 200 && st.h > 200 && Number.isFinite(st.x) && Number.isFinite(st.y))) return def;
  const d = screen.getDisplayMatching({ x: st.x, y: st.y, width: st.w, height: st.h }).workArea;
  const vis = Math.max(0, Math.min(st.x + st.w, d.x + d.width) - Math.max(st.x, d.x)) * Math.max(0, Math.min(st.y + st.h, d.y + d.height) - Math.max(st.y, d.y));
  if (vis < st.w * st.h * 0.5 || st.y < d.y - 8) return { ...def, max: !!st.max };
  const w = Math.min(st.w, d.width), h = Math.min(st.h, d.height);
  return { width: w, height: h, x: Math.max(d.x, Math.min(st.x, d.x + d.width - w)), y: Math.max(d.y, Math.min(st.y, d.y + d.height - h)), max: !!st.max };
}

let win = null; let shown = false;
function showWin() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  if (!win.isVisible()) win.show();
  win.focus();
  if (!shown) { shown = true; memo.boot = 'ok'; if (memo.safe) memo.safe = Math.max(0, memo.safe); saveMemo(); log('окно показано'); }
}
function create() {
  nativeTheme.themeSource = 'dark';
  const b = SELFTEST > 0 ? { width: 1200, height: 800 } : bounds();
  const wa = screen.getPrimaryDisplay().workArea;
  win = new BrowserWindow({
    width: b.width, height: b.height, x: b.x, y: b.y,
    minWidth: Math.min(1040, wa.width), minHeight: Math.min(680, wa.height),   // маленький экран — окно всё равно помещается
    backgroundColor: '#000000', show: false, title: 'Пульс',
    icon: path.join(__dirname, 'build', 'icon.png'),
    // своя шапка окна: системные кнопки Windows (свернуть / развернуть / закрыть) поверх тёмного фона
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#00000000', symbolColor: '#c7c7cc', height: 40 },
    trafficLightPosition: { x: 24, y: 20 },   // на Mac (для проверки) — кнопки окна внутри бокового меню
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, backgroundThrottling: true, enableWebSQL: false },
  });
  if (b.max) win.maximize();
  win.loadFile(path.join(__dirname, 'dist', 'index.html')).catch((e) => log('не загрузился интерфейс', e));
  if (SELFTEST > 0) return selftest();
  win.once('ready-to-show', showWin);
  // окно показываем в любом случае: если интерфейс не успел отрисоваться за 4 с — всё равно открываем
  setTimeout(() => { if (win && !shown) { log('окно открыто без ready-to-show'); showWin(); } }, 4000);
  // интерфейс упал — перезагружаем; упал снова в течение минуты — следующий запуск будет в безопасном режиме
  let gone = 0;
  win.webContents.on('render-process-gone', (_e, d) => {
    log('интерфейс завершился', d && d.reason, d && d.exitCode);
    if (!win || (d && d.reason === 'clean-exit')) return;
    if (++gone >= 2) { memo.safe = (memo.safe || 0) + 1; saveMemo(); }
    setTimeout(() => { if (win) win.webContents.reload(); }, 300);
    setTimeout(() => { gone = 0; }, 60000);
  });
  win.webContents.on('unresponsive', () => log('интерфейс не отвечает'));
  win.webContents.on('did-fail-load', (_e, code, desc) => log('ошибка загрузки интерфейса', code, desc));
  // от батареи / от сети — интерфейс может облегчить эффекты, чтобы ноутбук не грелся и дольше работал
  const sendPower = (v) => { if (win) win.webContents.send('power', v); };
  powerMonitor.on('on-battery', () => sendPower(true)); powerMonitor.on('on-ac', () => sendPower(false));
  const save = () => { if (!win) return; try { const nb = win.getNormalBounds(); if (!win.isMinimized() || nb.width > 200) fs.writeFileSync(stateFile(), JSON.stringify({ x: nb.x, y: nb.y, w: nb.width, h: nb.height, max: win.isMaximized() })); } catch {} };
  win.on('close', save);
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F11' && win) { e.preventDefault(); win.setFullScreen(!win.isFullScreen()); } });
  win.on('enter-full-screen', () => { if (win) win.webContents.send('win:fs', true); });
  win.on('leave-full-screen', () => { if (win) win.webContents.send('win:fs', false); });
  // ссылки наружу — в обычном браузере
  sec.hardenWindow(win);
  win.on('closed', () => { win = null; app.quit(); });
}
// самопроверка для установщика: интерфейс загрузился, React отрисовал меню — пишем «ok» и выходим
function selftest() {
  const done = (ok, why) => { try { fs.writeFileSync(selftestOut, JSON.stringify({ ok, why, version: app.getVersion(), safe: SAFE, gpu: app.getGPUFeatureStatus() })); } catch {} log('проверка:', ok ? 'успешно' : 'ошибка ' + why); app.exit(ok ? 0 : 3); };
  const t = setTimeout(() => done(false, 'интерфейс не загрузился за 25 с'), 25000);
  win.webContents.on('render-process-gone', (_e, d) => { clearTimeout(t); done(false, 'интерфейс упал: ' + (d && d.reason)); });
  win.webContents.on('did-fail-load', (_e, c, dsc) => { clearTimeout(t); done(false, 'не загрузился: ' + dsc); });
  win.webContents.once('did-finish-load', () => {
    const poll = async (n) => {
      let ok = false; try { ok = await win.webContents.executeJavaScript('!!document.querySelector(".app")'); } catch {}
      if (ok) { clearTimeout(t); return done(true, ''); }
      if (n > 0) setTimeout(() => poll(n - 1), 500); else { clearTimeout(t); done(false, 'интерфейс не отрисовался'); }
    };
    poll(30);
  });
}

// повторный щелчок по ярлыку: показываем уже открытое окно (а если окна почему-то нет — создаём заново)
app.on('second-instance', () => { log('повторный запуск — показываю окно'); if (!app.isReady()) return; if (!win) create(); else showWin(); });
// проверка ИИ-разметки разработчиком: PULSE_AI_TEST=1 Pulse --pulse-ai-test задание.json результат.json
const AITEST = process.argv.indexOf('--pulse-ai-test');
if (AITEST > 0 && process.env.PULSE_AI_TEST) app.whenReady().then(async () => {
  let r; try { r = { ok: true, v: await ai.testRun(JSON.parse(fs.readFileSync(process.argv[AITEST + 1], 'utf8'))) }; } catch (e) { r = { ok: false, error: String((e && e.stack) || e) }; }
  fs.writeFileSync(process.argv[AITEST + 2], JSON.stringify(r)); app.exit(0);
});
app.whenReady().then(() => { sec.setup(); create(); if (SELFTEST < 0) online.start(); }).catch((e) => {
  log('не удалось запустить', e);
  try { dialog.showErrorBox('Пульс', 'Не получилось запустить программу.\n\n' + (e && e.message) + '\n\nЖурнал: ' + logFile()); } catch {}
  app.exit(1);
});
app.on('window-all-closed', () => app.quit());
// закрыли — программа гарантированно выходит (ничего не «висит» в фоне и не мешает следующему запуску)
app.on('before-quit', () => { log('выход'); setTimeout(() => app.exit(0), 4000).unref(); });

// ---------- мост к Яндекс Музыке ----------
// интерфейс просит: ym:<метод>(токен, ...аргументы) → { ok, v } или { ok: false, error }
const METHODS = ['account', 'search', 'chart', 'artist', 'artistInfo', 'album', 'wave', 'waveFeedback', 'stream', 'lyrics'];
for (const m of METHODS) {
  sec.handle('ym:' + m, async (_e, ...args) => {
    try { return { ok: true, v: await ym[m](...args), tokenProblem: ym.tokenProblem() }; }
    catch (e) { console.log('[ym]', m, '→', e && e.message); return { ok: false, error: String((e && e.message) || e) }; }
  });
}
sec.handle('open-external', (_e, url) => { sec.openExternal(url); });

// ---------- обновления (см. updater.js) ----------
sec.handle('upd:check', async () => {
  try { return { ok: true, v: await upd.check() }; }
  catch (e) { return { ok: false, error: String((e && e.message) || e), nofeed: e && e.code === 'nofeed', current: app.getVersion() }; }
});
let installing = false;
sec.handle('upd:install', async (e) => {
  if (installing) return { ok: false, error: 'Обновление уже ставится' };
  installing = true;
  try { const v = await upd.install((f, label) => { try { e.sender.send('upd:progress', { f, label }); } catch {} }); return { ok: true, v }; }
  catch (er) { return { ok: false, error: String((er && er.message) || er) }; }
  finally { installing = false; }
});
sec.handle('upd:restart', () => { upd.restart(); });
// ---------- режим разработчика ----------
// Пароль в коде не хранится — только его отпечаток PBKDF2-SHA256 (соль + 210 000 повторов): исходники программы
// публичные (обновления на GitHub), поэтому сам пароль из них не достать. После 5 неверных попыток — пауза 60 с.
const DEV = { salt: '27afa81e579664c7131b22f453af8dfd', hash: 'f4c252ebf9b79edb6d829f200965c3cf2421babafddd929f226f16f80d620c0e', iter: 210000 };
let devFails = 0, devLockUntil = 0;
sec.handle('dev:unlock', async (_e, pw) => {
  const now = Date.now();
  if (now < devLockUntil) return { ok: false, wait: Math.ceil((devLockUntil - now) / 1000) };
  const got = await new Promise((res) => require('crypto').pbkdf2(String(pw || ''), Buffer.from(DEV.salt, 'hex'), DEV.iter, 32, 'sha256', (err, k) => res(err ? Buffer.alloc(32) : k)));
  const ok = require('crypto').timingSafeEqual(got, Buffer.from(DEV.hash, 'hex'));
  if (ok) { devFails = 0; sec.setDevOk(true); return { ok: true }; }
  if (++devFails >= 5) { devFails = 0; devLockUntil = now + 60000; return { ok: false, wait: 60 }; }
  return { ok: false, left: 5 - devFails };
});
sec.handle('online:get', () => (sec.isDevOk() ? online.count() : { ok: false, error: 'После перезапуска введите пароль разработчика ещё раз' }));
sec.handle('app:version', () => ({ version: app.getVersion(), electron: process.versions.electron, packaged: app.isPackaged }));

}   // конец: эта копия программы — единственная
