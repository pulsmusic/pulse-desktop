// ИИ-разметка живого текста: время каждого слова для треков, у которых есть только время строк.
//
// Как работает (всё само, пользователь ничего не нажимает):
// 1) Интерфейс спрашивает время слов для трека. Сначала ищем у себя (%APPDATA%\Pulse\ai\cache.json),
//    потом в общей базе на нашем сервере (тот же Cloudflare Worker, что и счётчик онлайна, адрес — из latest.json).
// 2) Нигде нет — и компьютер подходит (от сети, не слабый, не чаще 12 треков в час) — считаем сами, тихо:
//    в скрытом окне с низким приоритетом работает Whisper base (WebAssembly, один поток). Пакет с моделью (~140 МБ)
//    скачивается один раз из служебного релиза ai-pack-<N> на GitHub и сверяется по SHA-256.
// 3) Готовое время сохраняется у себя и отправляется в общую базу — дальше этот трек ни у кого не считается.
// На сервер уходят только числа (время слов), номер трека и отпечаток текста. Ни звука, ни текста, ни токена.
'use strict';
const { app, BrowserWindow, protocol, session, powerMonitor, ipcMain } = require('electron');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { readZip } = require('./updater');
const online = require('./online');

const PACK_V = 1;
const GH = 'https://github.com/pulsmusic/pulse-desktop/releases/download/';
const MANIFEST = GH + 'ai-pack-' + PACK_V + '/ai-pack.json';
const SCHEME = 'pulse-ai';
const dir = () => path.join(app.getPath('userData'), 'ai');
const packDir = () => path.join(dir(), 'pack-' + PACK_V);
let log = () => {};

// схема pulse-ai:// — модель и WebAssembly отдаются скрытому окну прямо с диска (fetch по file:// в Chromium не работает)
function registerScheme() {
  protocol.registerSchemesAsPrivileged([{ scheme: SCHEME, privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.wasm': 'application/wasm', '.json': 'application/json', '.txt': 'text/plain' };
let sessReady = false;
function aiSession() {
  const s = session.fromPartition('pulse-ai');
  if (!sessReady) {
    sessReady = true;
    s.protocol.handle(SCHEME, async (req) => {
      const u = new URL(req.url); const rel = path.normalize(decodeURIComponent(u.pathname)).replace(/^([/\\])+/, '');
      if (rel.startsWith('..') || path.isAbsolute(rel)) return new Response('', { status: 404 });
      // код разметки приходит с обновлением программы (ai-aligner.js) — модель в пакете остаётся прежней, перекачивать не нужно
      const own = rel === 'aligner.js' ? path.join(__dirname, 'ai-aligner.js') : '';
      try { const b = await fs.promises.readFile(own && fs.existsSync(own) ? own : path.join(packDir(), rel)); return new Response(b, { headers: { 'content-type': MIME[path.extname(rel)] || 'application/octet-stream' } }); }
      catch { return new Response('', { status: 404 }); }
    });
    s.setPermissionRequestHandler((_w, _p, cb) => cb(false));
    s.webRequest.onBeforeRequest((d, cb) => cb({ cancel: !d.url.startsWith(SCHEME + ':') && !d.url.startsWith('blob:') && !d.url.startsWith('data:') }));   // окно ИИ не ходит в интернет
  }
  return s;
}

// ---------- кэш у себя ----------
let cache = null;
// разметка v3 (0.14.6): старая база не используется — всё считается заново новым способом
const cacheFile = () => path.join(dir(), 'cache-v3.json');
function loadCache() {
  if (cache) return cache;
  try { fs.rmSync(path.join(dir(), 'cache.json'), { force: true }); } catch {}   // старый кэш (до v3) — удаляем
  try { cache = JSON.parse(fs.readFileSync(cacheFile(), 'utf8')) || {}; } catch { cache = {}; } return cache;
}
let saveT = null;
function saveCache() { clearTimeout(saveT); saveT = setTimeout(() => { try { fs.mkdirSync(dir(), { recursive: true }); const k = Object.keys(cache); for (let i = 0; i < k.length - 3000; i++) delete cache[k[i]]; fs.writeFileSync(cacheFile(), JSON.stringify(cache)); } catch {} }, 1500); }

// отпечаток текста: одинаковый текст — одинаковый отпечаток (у разных версий текста — своя разметка)
// «v3\n» в начале — новая база: старые разметки в общей базе (другой отпечаток) больше не находятся
const fingerprint = (lines) => crypto.createHash('sha256').update('v3\n' + lines.map((l) => String(l.text || '').trim().toLowerCase()).join('\n')).digest('hex').slice(0, 16);
const okId = (v) => typeof v === 'string' && /^[0-9A-Za-z:_.-]{1,48}$/.test(v);

async function serverGet(id, h) {
  const base = await online.base(); if (!base) return null;
  try {
    const r = await fetch(base + '/align?id=' + encodeURIComponent(id) + '&h=' + h, { signal: AbortSignal.timeout(8000), headers: { 'User-Agent': 'PulseDesktop/' + app.getVersion() } });
    if (!r.ok) return null; const j = await r.json(); return j && j.ok && j.v && Array.isArray(j.v.lines) ? j.v : null;
  } catch { return null; }
}
async function serverPut(id, h, v) {
  const base = await online.base(); if (!base) return;
  try { await fetch(base + '/align', { method: 'POST', headers: { 'content-type': 'application/json', 'User-Agent': 'PulseDesktop/' + app.getVersion() }, body: JSON.stringify({ id, h, lines: v.lines, c: v.c, m: 'whisper-base/v3', r: v.r || 0 }), signal: AbortSignal.timeout(10000) }); }
  catch (e) { log('ИИ: не удалось отправить разметку', e && e.message); }
}

// ---------- подходит ли компьютер, чтобы считать ----------
const hourly = [];
function canCompute(user) {
  if (!app.isPackaged && !process.env.PULSE_AI_TEST) return 'не установленная программа';
  if (!user) try { if (powerMonitor.isOnBatteryPower()) return 'от батареи'; } catch {}
  if (os.cpus().length < 4) return 'мало ядер';
  if (os.totalmem() < 6 * 1024 ** 3) return 'мало памяти';
  const now = Date.now(); while (hourly.length && now - hourly[0] > 3600e3) hourly.shift();
  if (!user && hourly.length >= 12) return 'лимит в час';
  return '';
}

// ---------- пакет с моделью ----------
let packP = null;
function packReady() { return fs.existsSync(path.join(packDir(), 'index.html')) && fs.existsSync(path.join(packDir(), 'models')); }
function ensurePack(onP = () => {}) {
  if (packReady()) return Promise.resolve(true);
  if (packP) return packP;
  packP = (async () => {
    const r0 = await fetch(MANIFEST + '?t=' + Date.now(), { redirect: 'follow', signal: AbortSignal.timeout(15000) });
    if (!r0.ok) throw new Error('пакет ИИ пока не выложен (' + r0.status + ')');
    const m = await r0.json();
    if (!m || !String(m.url).startsWith(GH) || !/^[0-9a-f]{64}$/.test(String(m.sha256))) throw new Error('описание пакета ИИ повреждено');
    log('ИИ: скачиваю пакет', m.size);
    const r = await fetch(m.url, { redirect: 'follow', signal: AbortSignal.timeout(30 * 60e3) });
    if (!r.ok || !r.body) throw new Error('пакет ИИ не скачался (' + r.status + ')');
    const parts = []; let got = 0, lastP = 0;
    for await (const c of r.body) { parts.push(Buffer.from(c)); got += c.length; if (m.size && got - lastP > 2e6) { lastP = got; onP(Math.min(0.99, got / m.size)); } if (powerMonitor.isOnBatteryPower()) throw new Error('перешли на батарею — докачаю позже'); }
    const buf = Buffer.concat(parts);
    if (crypto.createHash('sha256').update(buf).digest('hex') !== m.sha256) throw new Error('пакет ИИ скачался с ошибкой');
    const files = readZip(buf); const tmp = packDir() + '.tmp';
    fs.rmSync(tmp, { recursive: true, force: true });
    for (const f of files) { const p = path.join(tmp, f.name); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, f.data); }
    if (!fs.existsSync(path.join(tmp, 'index.html'))) throw new Error('в пакете ИИ не хватает файлов');
    fs.rmSync(packDir(), { recursive: true, force: true }); fs.renameSync(tmp, packDir());
    // старые версии пакета — удаляем
    for (const e of fs.readdirSync(dir())) if (/^pack-\d+$/.test(e) && e !== 'pack-' + PACK_V) fs.rmSync(path.join(dir(), e), { recursive: true, force: true });
    log('ИИ: пакет готов');
    return true;
  })().finally(() => { packP = null; });
  return packP;
}

// ---------- скрытое окно с ИИ ----------
let win = null, hello = null, idleT = null, pending = null;
function closeWin() { clearTimeout(idleT); if (win && !win.isDestroyed()) win.destroy(); win = null; hello = null; }
function ensureWin() {
  if (win && !win.isDestroyed()) return hello;
  win = new BrowserWindow({ show: false, width: 320, height: 240, skipTaskbar: true, focusable: false,
    webPreferences: { session: aiSession(), preload: path.join(__dirname, 'ai-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, spellcheck: false } });
  hello = new Promise((res, rej) => {
    const t = setTimeout(() => rej(new Error('окно ИИ не запустилось')), 60000);
    ipcMain.once('ai:hello', (e) => { if (win && e.sender === win.webContents) { clearTimeout(t); res(true); } });
  });
  win.webContents.on('render-process-gone', () => { if (pending) pending.reject(new Error('окно ИИ упало')); closeWin(); });
  win.webContents.on('did-start-loading', () => { try { const pid = win.webContents.getOSProcessId(); if (pid) os.setPriority(pid, os.constants.priority.PRIORITY_LOW); } catch {} });
  win.webContents.once('did-finish-load', () => { try { const pid = win.webContents.getOSProcessId(); if (pid) os.setPriority(pid, os.constants.priority.PRIORITY_LOW); } catch {} });
  win.loadURL(SCHEME + '://pack/index.html').catch(() => {});
  return hello;
}
ipcMain.on('ai:result', (e, r) => { if (!win || e.sender !== win.webContents || !pending || !r || r.id !== pending.id) return; const p = pending; pending = null; r.ok ? p.resolve(r.v) : p.reject(new Error(r.error || 'ошибка ИИ')); });

async function runJob(job) {
  if (!packReady()) setSt(job.id, { s: 'pack', p: 0 });
  await ensurePack((p) => setSt(job.id, { s: 'pack', p }));
  setSt(job.id, { s: 'run', p: 0 });
  await ensureWin();
  clearTimeout(idleT);
  const r = await fetch(job.url, { signal: AbortSignal.timeout(90000) });
  if (!r.ok) throw new Error('звук не скачался (' + r.status + ')');
  const audio = new Uint8Array(await r.arrayBuffer());
  if (audio.length > 60e6) throw new Error('слишком большой файл');
  const v = await new Promise((resolve, reject) => {
    pending = { id: job.id, resolve, reject };
    const t = setTimeout(() => { if (pending && pending.id === job.id) { pending = null; reject(new Error('ИИ не уложился в 15 минут')); closeWin(); } }, 15 * 60e3);
    const stop = () => { if (!job.scope && pending && pending.id === job.id && powerMonitor.isOnBatteryPower()) { clearTimeout(t); pending = null; reject(new Error('перешли на батарею')); closeWin(); } };
    powerMonitor.once('on-battery', stop);
    win.webContents.send('ai:job', { id: job.id, audio, lines: job.lines, scope: job.scope || undefined, prev: job.prev || undefined });
  });
  idleT = setTimeout(closeWin, 3 * 60e3);   // модель держим в памяти 3 минуты — вдруг следующий трек
  return v;
}

// ---------- состояние для индикатора в интерфейсе ----------
// s: wait (в очереди) · pack (скачивается модель, p — доля) · run (размечает, p — доля) · done · fail · skip (why — почему не считает)
const status = new Map(); let onStatus = () => {};
function setSt(id, v) { const o = { id, ...v, at: Date.now() }; status.set(id, o); if (status.size > 50) status.delete(status.keys().next().value); onStatus(o); }
ipcMain.on('ai:progress', (e, m) => { if (win && e.sender === win.webContents && m && pending && m.id === pending.id) setSt(m.id, { s: 'run', p: Math.max(0, Math.min(1, +m.p || 0)) }); });

// ---------- очередь ----------
const queue = []; let busy = false; const failed = new Map(); let notify = () => {};
async function pump() {
  if (busy || !queue.length) return;
  // пересчёт по кнопке пользователь попросил сам — для него не ждём зарядки и не смотрим на часовой лимит
  const why = queue[0].scope ? canCompute(true) : canCompute(); if (why) { log('ИИ: пока не считаю —', why); for (const j of queue) setSt(j.id, { s: 'skip', why }); queue.length = 0; return; }
  busy = true; const job = queue.shift();
  try {
    hourly.push(Date.now());
    log('ИИ: размечаю трек', job.id);
    const v = await runJob(job);
    log('ИИ: готово', job.id, 'уверенность', v.c, 'строк', v.lines.length, 'за', v.ms, 'мс');
    if (v.lines.length && (v.c >= 0.45 || job.scope)) {
      if (job.scope) v.r = (job.r || 0) + 1;   // пересчитанная по кнопке разметка заменяет прежнюю и в общей базе
      loadCache()[job.id + '|' + job.h] = { lines: v.lines, c: v.c, r: v.r || 0, at: Date.now() }; saveCache();
      serverPut(job.id, job.h, v); setSt(job.id, { s: 'done' }); notify(job.id);
    } else { failed.set(job.id + '|' + job.h, Date.now()); setSt(job.id, { s: 'fail', why: 'не узнал текст в песне' }); }
  } catch (e) { log('ИИ: не получилось', job.id, e && e.message); failed.set(job.id + '|' + job.h, Date.now()); setSt(job.id, { s: 'fail', why: String((e && e.message) || e) }); }
  busy = false; setTimeout(pump, 1500);
}

// запрос от интерфейса: { id, lines: [{ t, text }], url?, compute }
async function times(q) {
  if (!q || !okId(q.id) || !Array.isArray(q.lines) || !q.lines.length || q.lines.length > 600) return { ok: false };
  const lines = q.lines.map((l) => ({ t: +l.t || 0, text: String(l.text || '').slice(0, 400) }));
  const h = fingerprint(lines), key = q.id + '|' + h;
  const c = loadCache()[key]; if (c) return { ok: true, v: { lines: c.lines, c: c.c, src: 'cache' } };
  const s = await serverGet(q.id, h);
  if (s) { loadCache()[key] = { lines: s.lines, c: s.c, at: Date.now() }; saveCache(); return { ok: true, v: { lines: s.lines, c: s.c, src: 'server' } }; }
  if (q.compute && typeof q.url === 'string' && /^https:\/\//.test(q.url) && !(failed.get(key) > Date.now() - 24 * 3600e3)) {
    const why = canCompute(); if (why) { setSt(q.id, { s: 'skip', why }); return { ok: false, st: status.get(q.id) }; }
    if (!queue.some((j) => j.id === q.id) && !(busy && pending && pending.id === q.id) && queue.length < 4) { queue.push({ id: q.id, h, lines, url: q.url }); setSt(q.id, { s: 'wait' }); setTimeout(pump, 0); }
    return { ok: false, queued: true, st: status.get(q.id) };
  }
  return { ok: false };
}

// «Пересчитать» из интерфейса: { id, lines, url, scope: 'main' | 'ad' | 'all' } — ИИ слушает трек другими способами
// и берёт вариант, заметно отличающийся от прошлого (тот пользователь отметил как неверный)
function retry(q) {
  if (!q || !okId(q.id) || !Array.isArray(q.lines) || !q.lines.length || q.lines.length > 600) return { ok: false };
  if (!['main', 'ad', 'all'].includes(q.scope) || typeof q.url !== 'string' || !/^https:\/\//.test(q.url)) return { ok: false };
  const lines = q.lines.map((l) => ({ t: +l.t || 0, text: String(l.text || '').slice(0, 400) }));
  const h = fingerprint(lines), key = q.id + '|' + h; const c = loadCache()[key];
  failed.delete(key);
  for (let i = queue.length - 1; i >= 0; i--) if (queue[i].id === q.id) queue.splice(i, 1);
  if (busy && pending && pending.id === q.id) return { ok: true, busy: true };
  queue.unshift({ id: q.id, h, lines, url: q.url, scope: q.scope, prev: c ? c.lines : null, r: c ? c.r || 0 : 0 });
  setSt(q.id, { s: 'wait', retry: true }); setTimeout(pump, 0);
  return { ok: true };
}

// проверка разработчика (только с PULSE_AI_TEST): разметить один трек напрямую, минуя очередь и сервер
async function testRun(q) {
  const lines = q.lines.map((l) => ({ t: +l.t || 0, text: String(l.text || '') }));
  const t0 = Date.now(); const v = await runJob({ id: q.id, h: fingerprint(lines), lines, url: q.url });
  closeWin(); return { ...v, wall: Date.now() - t0, pack: state().pack };
}
function setup(opts) { log = opts.log || log; notify = opts.notify || notify; onStatus = opts.onStatus || onStatus; }
const statusOf = (id) => status.get(String(id)) || null;
function state() { const cache = loadCache(); return { pack: packReady() ? 'готов' : packP ? 'скачивается' : 'нет', busy, cur: busy && pending ? statusOf(pending.id) : null, queue: queue.length, can: canCompute() || 'да', cached: Object.keys(cache).length }; }
module.exports = { registerScheme, setup, times, retry, state, testRun, statusOf };
