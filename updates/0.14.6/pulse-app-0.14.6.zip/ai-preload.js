// Мост скрытого окна ИИ: получить задание (звук + строки), вернуть результат. Больше окно ничего не умеет.
'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('aiBridge', {
  onJob: (cb) => ipcRenderer.on('ai:job', (_e, j) => cb(j)),
  done: (r) => ipcRenderer.send('ai:result', r),
  progress: (id, p) => ipcRenderer.send('ai:progress', { id, p }),
  hello: () => ipcRenderer.send('ai:hello'),
});
