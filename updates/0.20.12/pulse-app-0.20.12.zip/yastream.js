// Звук Яндекса через саму программу: адрес pulseya://s/<id>.
// • Без потерь (FLAC) Яндекс отдаёт зашифрованным (AES-CTR, ключ приходит вместе со ссылкой под токен пользователя) —
//   здесь он расшифровывается на лету, кусками, по мере того как плеер просит данные. На диск ничего не пишется.
// • Обычные ссылки тоже идут через эту схему: окно всегда может подключить к звуку эквалайзер (Web Audio),
//   не завися от того, разрешает ли сервер Яндекса чтение звука странице (CORS).
// Перемотка работает: плеер просит кусок с любого места, счётчик AES-CTR сдвигается на нужный блок.
'use strict';
const crypto = require('crypto');

const reg = new Map();   // id → { urls, key, type, t }
const LIFE = 6 * 3600 * 1000, MAX = 300;
const TYPE = { flac: 'audio/flac', 'flac-mp4': 'audio/mp4', mp3: 'audio/mpeg', aac: 'audio/mp4', 'he-aac': 'audio/mp4', 'aac-mp4': 'audio/mp4', 'he-aac-mp4': 'audio/mp4' };
const yandexHost = (u) => { try { const x = new URL(u); return x.protocol === 'https:' && /(^|\.)(yandex\.(net|ru|com)|yastatic\.net)$/.test(x.hostname); } catch { return false; } };

// ссылки (и ключ, если звук зашифрован) → адрес для плеера
function add({ urls, key, codec }) {
  urls = [].concat(urls || []).filter(yandexHost);
  if (!urls.length) throw new Error('Нет ссылки на звук');
  const now = Date.now();
  for (const [k, v] of reg) if (now - v.t > LIFE || reg.size > MAX) reg.delete(k); else break;
  const id = crypto.randomBytes(12).toString('hex');
  reg.set(id, { urls, key: key && /^[0-9a-f]{32}([0-9a-f]{32})?$/i.test(key) ? Buffer.from(key, 'hex') : null, type: TYPE[String(codec || '').toLowerCase()] || 'audio/mpeg', t: now });
  return 'pulseya://s/' + id;
}

// формат звука по первым байтам ответа: частота и разрядность (FLAC — из STREAMINFO, AAC — из описания в MP4,
// MP3 — из заголовка кадра). Яндекс сам их не сообщает, а показать «24 бит · 48 кГц» хочется честно
const MP3_SR = [44100, 48000, 32000];
function sniff(b) {
  const at = (tag) => b.indexOf(tag, 0, 'latin1');
  let i = at('fLaC'); const d = at('dfLa');
  if (d >= 0) i = d + 8;   // FLAC в MP4: после «dfLa» — версия (4 байта), дальше как в файле FLAC без «fLaC»
  else if (i >= 0) i += 4;
  if (i >= 0 && b.length >= i + 4 + 18) { const o = i + 4 + 10; const sr = (b[o] << 12) | (b[o + 1] << 4) | (b[o + 2] >> 4); const bits = (((b[o + 2] & 1) << 4) | (b[o + 3] >> 4)) + 1; if (sr > 0) return { codec: 'FLAC', sr, bits }; }
  const m = at('mp4a'); if (m >= 0 && b.length >= m + 32) { const sr = b.readUInt16BE(m + 28); if (sr) return { codec: 'AAC', sr, bits: 0 }; }
  for (let k = 0; k + 4 < Math.min(b.length, 8192); k++) {
    if (b[k] === 0xff && (b[k + 1] & 0xe6) === 0xe2) { const v = (b[k + 1] >> 3) & 3, sri = (b[k + 2] >> 2) & 3; if (sri < 3 && v !== 1) return { codec: 'MP3', sr: MP3_SR[sri] / (v === 3 ? 1 : v === 2 ? 2 : 4), bits: 0 }; }
  }
  return null;
}
const fmts = new Map();   // адрес → { codec, sr, bits } (что узнали из звука)
function fmtOf(url) { const id = String(url || '').replace(/^pulseya:\/\/s\//, ''); return fmts.get(id) || null; }

// расшифровщик с нужного места: блок AES — 16 байт, счётчик — номер блока (как у Яндекса: nonce из нулей)
function decipherAt(key, pos) {
  const iv = Buffer.alloc(16); iv.writeBigUInt64BE(BigInt(Math.floor(pos / 16)), 8);
  const d = crypto.createDecipheriv(key.length === 32 ? 'aes-256-ctr' : 'aes-128-ctr', key, iv);
  const skip = pos % 16; if (skip) d.update(Buffer.alloc(skip));
  return d;
}

const H = (extra) => ({ 'access-control-allow-origin': '*', 'cache-control': 'no-store', 'accept-ranges': 'bytes', ...extra });
async function serve(req) {
  let u; try { u = new URL(req.url); } catch { return new Response(null, { status: 400, headers: H() }); }
  const e = u.hostname === 's' && reg.get(u.pathname.replace(/^\/+/, ''));
  if (!e) return new Response(null, { status: 404, headers: H() });
  const range = req.headers.get('range') || '';
  if (!range || /^bytes=0-/.test(range)) try { require('./perfwatch').kick('Яндекс'); } catch {}
  let up = null, lastErr = null;
  for (const src of e.urls) {
    try {
      up = await fetch(src, { headers: range ? { Range: range } : {}, redirect: 'follow', signal: AbortSignal.timeout(20000) });
      if (up.ok || up.status === 206) break;
      lastErr = new Error('HTTP ' + up.status); try { up.body && up.body.cancel(); } catch {} up = null;
    } catch (er) { lastErr = er; up = null; }
  }
  if (!up) { if (up === null && lastErr) console.log('[yastream]', lastErr.message); return new Response(null, { status: 502, headers: H() }); }
  if (up.status === 416) return new Response(null, { status: 416, headers: H({ 'content-range': up.headers.get('content-range') || '' }) });
  const cr = up.headers.get('content-range') || '';
  const start = up.status === 206 ? +((/bytes (\d+)-/.exec(cr) || [])[1] || 0) : 0;
  const len = up.headers.get('content-length');
  const out = H({ 'content-type': e.type, ...(len ? { 'content-length': len } : {}), ...(up.status === 206 && cr ? { 'content-range': cr } : {}) });
  const id = u.pathname.replace(/^\/+/, ''); let head = fmts.has(id) ? null : [], hn = 0;
  const look = (chunk) => { if (!head) return; head.push(Buffer.from(chunk)); hn += chunk.length; const b = Buffer.concat(head); const f = sniff(b); if (f) { fmts.set(id, f); if (fmts.size > MAX) fmts.delete(fmts.keys().next().value); head = null; } else if (hn > 256 * 1024) head = null; else head = [b]; };
  // Плеер просит звук «впрок» так быстро, как позволяет интернет: на смене трека это был всплеск нагрузки
  // (скачать, расшифровать и передать в окно десятки мегабайт за пару секунд). Теперь первые 6 МБ — сразу (трек
  // стартует так же быстро), дальше — не быстрее 3 МБ/с: это в 2,5 раза быстрее самого тяжёлого FLAC (24 бит / 192 кГц),
  // запас в буфере плеера растёт, а процессор не нагружается рывком.
  const BURST = 6 * 1024 * 1024, RATE = 3 * 1024 * 1024; let sent = 0, t0 = 0;
  const pace = async (n) => { if (!t0) t0 = Date.now(); sent += n; const over = sent - BURST - (RATE * (Date.now() - t0)) / 1000; if (over > 0) await new Promise((r) => setTimeout(r, Math.min(2000, (over / RATE) * 1000))); };
  if (!e.key) {
    const rd0 = up.body.getReader();
    return new Response(new ReadableStream({ async pull(c) { try { const { done, value } = await rd0.read(); if (done) { c.close(); return; } look(value); c.enqueue(value); await pace(value.length); } catch (er) { c.error(er); } }, cancel() { rd0.cancel().catch(() => {}); } }), { status: up.status, headers: out });
  }
  const dec = decipherAt(e.key, start); const rd = up.body.getReader();
  const body = new ReadableStream({
    async pull(c) {
      try {
        const { done, value } = await rd.read();
        if (done) { const f = dec.final(); if (f.length) c.enqueue(new Uint8Array(f)); c.close(); return; }
        const b = dec.update(Buffer.from(value.buffer, value.byteOffset, value.byteLength)); look(b); c.enqueue(new Uint8Array(b.buffer, b.byteOffset, b.length)); await pace(b.length);
      } catch (er) { c.error(er); }
    },
    cancel() { rd.cancel().catch(() => {}); },
  });
  return new Response(body, { status: up.status, headers: out });
}

function setup(protocol, log) {
  protocol.handle('pulseya', (req) => serve(req).catch((er) => { (log || console.log)('звук Яндекса: отдача', er && er.message); return new Response(null, { status: 500, headers: H() }); }));
}
module.exports = { add, setup, decipherAt, serve, sniff, fmtOf };
