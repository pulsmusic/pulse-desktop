// Обновления «Пульса» для Windows — без переустановки.
//
// Откуда: релизы GitHub репозитория pulsmusic/pulse-desktop. В каждом релизе — файл latest.json (какая версия,
// что нового, ссылка на пакет и его контрольная сумма SHA-256) и сам пакет pulse-app-<версия>.zip (~0,7 МБ):
// только файлы «Пульса» (main.js, preload.js, yandex.js, updater.js, package.json, dist/, build/icon.png).
// Electron (основа программы, ~110 МБ) не скачивается — он уже установлен. Если новой версии нужен другой Electron,
// latest.json говорит об этом (minElectron), и программа предложит скачать новый установщик.
//
// Как ставится: пакет скачивается во временную папку, сверяется по SHA-256, распаковывается и проверяется
// (есть main.js, интерфейс, версия совпадает). Текущие файлы копируются в резервную папку
// (%APPDATA%\Pulse\update-backup), новые записываются на их место, и программа перезапускается.
// Токен, лайки и настройки не трогаются — они хранятся отдельно (%APPDATA%\Pulse).
'use strict';
const { app } = require('electron');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const FEED = process.env.PULSE_UPDATE_FEED || 'https://github.com/pulsmusic/pulse-desktop/releases/latest/download/latest.json';
const RELEASES = 'https://github.com/pulsmusic/pulse-desktop/releases/latest';

// «0.9.10» > «0.9.9»
function newer(a, b) {
  const pa = String(a).split(/[.-]/).map((x) => parseInt(x, 10) || 0), pb = String(b).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}

async function getJSON(url) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { headers: { 'User-Agent': 'PulseDesktop/' + app.getVersion(), Accept: 'application/json' }, signal: AbortSignal.timeout(15000), redirect: 'follow' });
  if (r.status === 404) throw Object.assign(new Error('Обновлений пока не выкладывали'), { code: 'nofeed' });
  if (!r.ok) throw new Error('Сервер обновлений ответил ' + r.status);
  return r.json();
}

let latest = null;   // последний прочитанный latest.json

async function check() {
  const cur = app.getVersion();
  const m = await getJSON(FEED);
  if (!m || !m.version || !m.url || !/^[0-9a-f]{64}$/i.test(String(m.sha256 || ''))) throw new Error('Файл обновлений повреждён');
  latest = m;
  const available = newer(m.version, cur);
  const needInstaller = !!(m.minElectron && newer(m.minElectron, process.versions.electron));
  return { current: cur, version: m.version, available, notes: Array.isArray(m.notes) ? m.notes.slice(0, 12) : [], size: m.size || 0,
    date: m.date || '', needInstaller, installer: m.installer || RELEASES, packaged: app.isPackaged };
}

// ---------- распаковка zip без сторонних библиотек ----------
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('пакет обновления повреждён (не zip)');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('пакет обновления повреждён');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl);
    p += 46 + nl + xl + cl;
    if (name.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('пакет обновления повреждён');
    const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28);
    const raw = buf.subarray(start, start + csize);
    const data = method === 0 ? Buffer.from(raw) : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data) throw new Error('пакет обновления сжат неизвестным способом');
    if (data.length !== usize) throw new Error('пакет обновления повреждён (размер)');
    // только безопасные пути внутри папки программы
    const rel = path.normalize(name).replace(/^([/\\])+/, '');
    if (rel.startsWith('..') || path.isAbsolute(rel)) continue;
    out.push({ name: rel, data });
  }
  return out;
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}

// progress(доля 0…1, подпись)
// пакет скачивается только из релизов «Пульса» на GitHub (кроме проверки с подменённым адресом PULSE_UPDATE_FEED)
const PKG_PREFIX = 'https://github.com/pulsmusic/pulse-desktop/releases/download/';
async function install(progress) {
  if (!process.env.PULSE_UPDATE_FEED && latest && !String(latest.url).startsWith(PKG_PREFIX)) throw new Error('Адрес пакета обновления не похож на релиз «Пульса» — обновление отменено');
  if (!app.isPackaged) throw new Error('Обновления ставятся только в установленный «Пульс» (через установщик). Сейчас программа запущена для проверки.');
  // Перед скачиванием всегда заново читаем latest.json: если пока программа ждала, вышло ещё несколько версий,
  // ставится сразу самая последняя (пакет — полная программа, промежуточные версии не нужны).
  progress(0, 'Проверяю последнюю версию');
  let m = latest;
  try {
    const f = await getJSON(FEED);
    if (f && f.version && f.url && /^[0-9a-f]{64}$/i.test(String(f.sha256 || '')) && (!m || !newer(m.version, f.version))) m = f;
  } catch (e) { if (!m) throw e; }
  if (!newer(m.version, app.getVersion())) throw new Error('У вас уже последняя версия');
  latest = m;
  if (!process.env.PULSE_UPDATE_FEED && !String(m.url).startsWith(PKG_PREFIX)) throw new Error('Адрес пакета обновления не похож на релиз «Пульса» — обновление отменено');
  if (m.minElectron && newer(m.minElectron, process.versions.electron)) throw new Error('Для этой версии нужен новый установщик');
  progress(0, 'Скачиваю версию ' + m.version);
  const r = await fetch(m.url, { headers: { 'User-Agent': 'PulseDesktop/' + app.getVersion() }, redirect: 'follow', signal: AbortSignal.timeout(120000) });
  if (!r.ok || !r.body) throw new Error('Не получилось скачать обновление (ответ ' + r.status + ')');
  const total = Number(r.headers.get('content-length')) || m.size || 0; const parts = []; let got = 0;
  for await (const chunk of r.body) { parts.push(Buffer.from(chunk)); got += chunk.length; if (total) progress(Math.min(0.85, (got / total) * 0.85), 'Скачиваю версию ' + m.version); }
  const buf = Buffer.concat(parts);
  const sum = crypto.createHash('sha256').update(buf).digest('hex');
  if (sum.toLowerCase() !== String(m.sha256).toLowerCase()) throw new Error('Обновление скачалось с ошибкой (не совпала контрольная сумма). Попробуйте ещё раз.');
  progress(0.88, 'Проверяю файлы');
  const files = readZip(buf);
  const has = (n) => files.some((f) => f.name.replace(/\\/g, '/') === n);
  if (!has('main.js') || !has('preload.js') || !has('dist/index.html') || !has('package.json') || !has('security.js') || !has('online.js')) throw new Error('В пакете обновления не хватает файлов');
  const pkg = JSON.parse(files.find((f) => f.name === 'package.json').data.toString('utf8'));
  if (pkg.version !== m.version) throw new Error('Версия в пакете не совпадает с объявленной');

  // резервная копия текущей версии, затем запись новой
  const appDir = app.getAppPath();
  const backup = path.join(app.getPath('userData'), 'update-backup');
  progress(0.92, 'Сохраняю резервную копию');
  fs.rmSync(backup, { recursive: true, force: true });
  copyDir(appDir, backup);
  progress(0.96, 'Ставлю обновление');
  try {
    fs.rmSync(path.join(appDir, 'dist'), { recursive: true, force: true });   // старые файлы интерфейса не смешиваются с новыми
    for (const f of files) {
      const to = path.join(appDir, f.name);
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.writeFileSync(to, f.data);
    }
  } catch (e) {
    // не получилось — возвращаем как было
    try { copyDir(backup, appDir); } catch {}
    throw new Error('Не получилось записать файлы обновления: ' + e.message);
  }
  progress(1, 'Перезапускаю');
  return { version: m.version };
}

function restart() { app.relaunch(); app.exit(0); }

module.exports = { check, install, restart, newer, readZip, FEED };
