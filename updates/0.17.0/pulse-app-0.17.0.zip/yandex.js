// Пульс для Windows — клиент Яндекс Музыки (работает в главном процессе Electron, на Node.js).
// Тот же неофициальный API, что и у библиотеки MarshalX/yandex-music-api (её использует сервер телефонной версии),
// только переписанный на JavaScript — поэтому на компьютере отдельный сервер не нужен.
// Токен пользователя хранится только на этом компьютере и уходит только на api.music.yandex.net.
'use strict';
const crypto = require('crypto');

const BASE = 'https://api.music.yandex.net';
const SIGN_SALT = 'XGRlBW9FXlekgbPrRHuSiA';   // соль подписи ссылки на mp3 (как в yandex_music/download_info.py)
const LYR_KEY = 'p93jhgh689SBReK6ghtw62';      // ключ подписи запроса текста (как в yandex_music/utils/sign_request.py)
const HEAD = { 'X-Yandex-Music-Client': 'YandexMusicAndroid/24023621', 'Accept-Language': 'ru', 'User-Agent': 'Yandex-Music-API' };

let tokenBad = '';
let hasPlus = null;   // есть ли Яндекс Плюс (узнаём из account) — без него звук без потерь не приходит
const ys = require('./yastream');   // причина, если токен не подошёл (видно в настройках)

const clean = (t) => {
  t = String(t || '').trim();
  if (t.includes('access_token=')) t = t.split('access_token=')[1];
  return t.split('&')[0].trim();
};

// токен уходит только на серверы Яндекса — даже если какой-то ответ подсунет ссылку на чужой сайт
const yandexHost = (u) => { try { const h = new URL(u).hostname; return /(^|\.)yandex\.(net|ru|com)$/.test(h); } catch { return false; } };
async function raw(path, token, opt = {}) {
  if (token && path.startsWith('http') && !yandexHost(path)) token = '';
  const headers = { ...HEAD };
  if (token) headers.Authorization = 'OAuth ' + token;
  if (opt.form) headers['Content-Type'] = 'application/x-www-form-urlencoded';
  if (opt.json) headers['Content-Type'] = 'application/json';
  const r = await fetch(path.startsWith('http') ? path : BASE + path, {
    method: opt.method || 'GET', headers, body: opt.form ? new URLSearchParams(opt.form).toString() : opt.json ? JSON.stringify(opt.json) : undefined,
    signal: AbortSignal.timeout(opt.timeout || 15000),
  });
  const text = await r.text();
  if (opt.text) { if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status }); return text; }
  let d = null; try { d = JSON.parse(text); } catch { /* не JSON */ }
  if (!r.ok) {
    const e = new Error((d && d.error && (d.error.message || d.error.name)) || 'Яндекс ответил ' + r.status);
    e.status = r.status; throw e;
  }
  return d ? d.result : null;
}

// запрос с токеном; если токен не подошёл (401/403) — повторяем без него, приложение продолжает работать
let waveCfgKey = '', waveStarted = false, waveBatch = '';   // состояние «Моей волны»
async function ym(path, token, opt) {
  token = clean(token);
  if (!token) return raw(path, '', opt);
  try { const v = await raw(path, token, opt); tokenBad = ''; return v; }
  catch (e) {
    if (e.status === 401 || e.status === 403) { tokenBad = 'Токен не подошёл (' + e.status + '). Работаю без входа — 30-секундные фрагменты'; return raw(path, '', opt); }
    throw e;
  }
}

// ---------- перевод в простой вид для интерфейса ----------
const cover = (u, s = '400x400') => (u ? 'https://' + String(u).replace('%%', s) : '');
function track(t) {
  if (!t || t.available === false || !t.title) return null;
  const al = (t.albums || [])[0];
  return {
    id: String(t.id),
    title: t.title + (t.version ? ' (' + t.version + ')' : ''),
    artist: (t.artists || []).map((a) => a.name).filter(Boolean).join(', '),
    artists: (t.artists || []).map((a) => ({ id: String(a.id), name: a.name })),
    album: al ? { id: String(al.id), title: al.title, year: al.year } : null,
    cover: cover(t.coverUri || (al && al.coverUri)),
    coverBig: cover(t.coverUri || (al && al.coverUri), '1000x1000'),
    dur: Math.round((t.durationMs || 0) / 1000),
    explicit: t.contentWarning === 'explicit',
    genre: (al && al.genre) || '',
    // есть ли у трека текст: 2 — живой (строки с таймкодами), 1 — только текст, 0 — нет, null — Яндекс не сказал
    lyrics: t.lyricsInfo ? (t.lyricsInfo.hasAvailableSyncLyrics ? 2 : t.lyricsInfo.hasAvailableTextLyrics ? 1 : 0) : null,
  };
}
// новый способ получить звук (так же делает приложение Яндекс Музыки): подписанный запрос get-file-info.
// Подпись — HMAC-SHA256 тем же ключом, что и у запроса текста (LYR_KEY), от склеенных параметров без запятых.
const CODECS = ['flac', 'flac-mp4', 'mp3', 'aac', 'he-aac', 'aac-mp4', 'he-aac-mp4'];
async function fileInfo(token, id, q) {
  const p = { ts: Math.floor(Date.now() / 1000), trackId: String(id).split(':')[0], quality: q, codecs: CODECS.join(','), transports: 'encraw' };
  const sign = crypto.createHmac('sha256', LYR_KEY).update(Object.values(p).join('').replace(/,/g, '')).digest('base64').slice(0, -1);
  const qs = new URLSearchParams({ ...p, sign }).toString();
  const r = await raw('/get-file-info?' + qs, token, { timeout: 12000 });
  const d = r && r.downloadInfo;
  if (!d || !(d.urls || d.url)) throw new Error('нет ссылки');
  const codec = String(d.codec || '').toLowerCase();
  const url = ys.add({ urls: d.urls || [d.url], key: d.key, codec });
  return { url, preview: false, bitrate: d.bitrate || 0, codec, quality: d.quality || q, lossless: /flac/.test(codec) };
}
const tracks = (l) => (l || []).map(track).filter(Boolean);
const artist = (a) => (a ? { id: String(a.id), name: a.name, photo: cover((a.cover && a.cover.uri) || a.ogImage), genres: a.genres || [] } : null);
// плейлист Яндекса (подборки редакции, «Плейлист дня», «Дежавю»…) → простой вид
const playlist = (p) => (p && (p.kind != null) ? {
  uid: String((p.owner && p.owner.uid) || p.uid || ''), kind: String(p.kind), title: p.title || 'Плейлист',
  desc: String(p.description || '').replace(/\s+/g, ' ').slice(0, 220), count: p.trackCount || 0,
  cover: cover((p.cover && (p.cover.uri || (p.cover.itemsUri && p.cover.itemsUri[0]))) || p.ogImage),
  coverBig: cover((p.cover && (p.cover.uri || (p.cover.itemsUri && p.cover.itemsUri[0]))) || p.ogImage, '1000x1000'),
} : null);
const album = (a) => (a ? {
  id: String(a.id), title: a.title, artist: (a.artists || []).map((x) => x.name).join(', '),
  artistId: a.artists && a.artists[0] ? String(a.artists[0].id) : '', cover: cover(a.coverUri), coverBig: cover(a.coverUri, '1000x1000'),
  year: a.year || null, type: a.type || 'album', count: a.trackCount || 0,
} : null);

// номер аккаунта (нужен для «Мне нравится»); запоминаем на время работы программы
const uids = new Map();
async function myUid(token) {
  if (uids.has(token)) return uids.get(token);
  const r = await raw('/account/status', token);
  const uid = String((r && r.account && r.account.uid) || '');
  if (!uid) throw new Error('Яндекс не отдал номер аккаунта');
  uids.set(token, uid); return uid;
}

// ---------- точки API ----------
const api = {
  async account(token) {
    token = clean(token);
    if (!token) return { auth: false };
    try {
      const r = await raw('/account/status', token);
      tokenBad = '';
      hasPlus = !!(r.plus && r.plus.hasPlus);
      return { auth: true, login: (r.account && (r.account.displayName || r.account.login)) || '', plus: hasPlus };
    } catch (e) { tokenBad = 'Токен не подошёл: ' + e.message; return { auth: false, error: tokenBad }; }
  },
  async search(token, q) {
    const r = await ym('/search?text=' + encodeURIComponent(q) + '&type=all&page=0&nocorrect=false', token);
    return {
      tracks: tracks(r && r.tracks && r.tracks.results).slice(0, 30),
      artists: ((r && r.artists && r.artists.results) || []).map(artist).filter(Boolean).slice(0, 12),
      albums: ((r && r.albums && r.albums.results) || []).map(album).filter(Boolean).slice(0, 12),
    };
  },
  async chart(token) {
    const r = await ym('/landing3/chart/russia', token);
    return tracks(((r && r.chart && r.chart.tracks) || []).map((x) => x.track)).slice(0, 100);
  },
  async artist(token, id) {
    const [bi, tr] = await Promise.all([
      ym('/artists/' + id + '/brief-info', token),
      ym('/artists/' + id + '/tracks?page-size=50', token).catch(() => null),
    ]);
    const al = await ym('/artists/' + id + '/direct-albums?page-size=50&sort-by=year', token).catch(() => null);
    const a0 = bi && bi.artist; const info = artist(a0);
    if (info) {
      const d = a0.description;
      info.description = (d && (d.text || d)) || '';
      if (typeof info.description !== 'string') info.description = '';
      info.counts = a0.counts || {};
      info.countries = a0.countries || [];
      // настоящая статистика Яндекс Музыки (brief-info): слушатели за месяц и их прирост, лайки исполнителя,
      // число треков и альбомов во всём каталоге (а не только загруженных 50)
      const st = bi.stats || {};
      info.listeners = st.lastMonthListeners || 0;
      info.listenersDelta = st.lastMonthListenersDelta || 0;
      info.likes = a0.likesCount || 0;
      info.ratingMonth = (a0.ratings && a0.ratings.month) || 0;
      info.photoBig = cover((a0.cover && a0.cover.uri) || a0.ogImage, '1000x1000');
      const all = (al && al.albums) || [];   // год первого релиза — только если список альбомов полный
      const years = all.length < 50 ? all.map((x) => x.year).filter((y) => y > 1900) : [];
      info.firstYear = years.length ? Math.min(...years) : 0;
    }
    return {
      info,
      tracks: tracks((tr && tr.tracks) || (bi && bi.popularTracks)),
      albums: ((al && al.albums) || (bi && bi.albums) || []).map(album).filter(Boolean),
      similar: ((bi && bi.similarArtists) || []).map(artist).filter(Boolean).slice(0, 12),
    };
  },
  // витрина главной: персональные подборки (нужен вход), новые релизы, подборки редакции
  async landing(token) {
    const r = await ym('/landing3?blocks=personalplaylists,new-releases,new-playlists', token, { timeout: 12000 });
    const out = { personal: [], releases: [], playlists: [] }; const seen = new Set();
    for (const b of (r && r.blocks) || []) for (const e of b.entities || []) {
      const d = e && e.data;
      if (e.type === 'personal-playlist' && d && d.data) { const p = playlist(d.data); if (p && p.uid) out.personal.push({ ...p, special: d.type || '' }); }
      else if (e.type === 'album' && d) { const a = album(d); if (a && !seen.has('a' + a.id)) { seen.add('a' + a.id); out.releases.push(a); } }
      else if (e.type === 'playlist' && d) { const p = playlist(d); if (p && p.uid && !seen.has('p' + p.uid + p.kind)) { seen.add('p' + p.uid + p.kind); out.playlists.push(p); } }
    }
    return out;
  },
  // треки плейлиста Яндекса; если пришли только номера треков — дозапрашиваем сами треки
  async playlist(token, uid, kind) {
    const p = await ym('/users/' + encodeURIComponent(uid) + '/playlists/' + encodeURIComponent(kind), token);
    const short = (p && p.tracks) || [];
    let full = short.map((x) => x && x.track).filter(Boolean);
    if (!full.length && short.length) {
      const ids = short.slice(0, 150).map((x) => x.id + (x.albumId ? ':' + x.albumId : '')).join(',');
      full = (await ym('/tracks', token, { method: 'POST', form: { 'track-ids': ids, 'with-positions': 'false' } }).catch(() => [])) || [];
    }
    return { info: playlist(p), tracks: tracks(full) };
  },
  async artistInfo(token, id) {
    const bi = await ym('/artists/' + id + '/brief-info', token);
    return artist(bi && bi.artist);
  },
  async album(token, id) {
    const a = await ym('/albums/' + id + '/with-tracks', token);
    return { info: album(a), tracks: tracks([].concat(...((a && a.volumes) || []))) };
  },
  // «Моя волна» — персональный бесконечный поток Яндекса (нужен вход)
  // «Моя волна». cfg — фильтры «Моего пульса»: mood (fun / active / calm / sad / all), kind (favorite / discover /
  // popular / default), lang (russian / not-russian / any). Это настройки самой волны Яндекса (как «Настроить» в
  // приложении Яндекс Музыки) — отправляются, только когда меняются. after — id последнего трека в очереди:
  // Яндекс продолжает поток с этого места.
  async wave(token, after, cfg) {
    if (!clean(token)) return { tracks: [], need: 'token' };
    const c = { mood: 'all', kind: 'default', lang: 'any', ...(cfg || {}) };
    const k = [clean(token).slice(-6), c.mood, c.kind, c.lang].join('|');
    if (cfg && k !== waveCfgKey) {   // фильтры не трогали — настройки волны в аккаунте не меняем
      try { await raw('/rotor/station/user:onyourwave/settings3', clean(token), { method: 'POST', json: { moodEnergy: c.mood, diversity: c.kind, language: c.lang, type: 'rotor' }, timeout: 8000 }); waveCfgKey = k; waveStarted = false; }
      catch (e) { console.log('[ym] wave settings →', e && e.message); }
    }
    if (!waveStarted) { waveStarted = true; this.waveFeedback(token, 'radioStarted', '', 0).catch(() => {}); }
    const r = await ym('/rotor/station/user:onyourwave/tracks?settings2=true' + (after ? '&queue=' + encodeURIComponent(after) : ''), token, { timeout: 10000 });
    if (r && r.batchId) waveBatch = r.batchId;
    return { tracks: tracks(((r && r.sequence) || []).map((x) => x.track)) };
  },
  // отзыв волне: трек начали / пролистнули / дослушали — без этого Яндекс иногда отдаёт одну и ту же пачку снова
  async waveFeedback(token, type, trackId, played) {
    if (!clean(token)) return false;
    const body = { type, timestamp: new Date().toISOString(), from: 'desktop_win-radio-user-onyourwave' };
    if (trackId) { body.trackId = String(trackId); body.totalPlayedSeconds = Math.max(0, Math.round(played || 0)); }
    await raw('/rotor/station/user:onyourwave/feedback' + (waveBatch ? '?batch-id=' + encodeURIComponent(waveBatch) : ''), clean(token), { method: 'POST', json: body, timeout: 8000 });
    return true;
  },
  // звук трека. q — качество: 'lq' (низкое, AAC 64), 'nq' (среднее, AAC 192), 'lossless' (без потерь, FLAC до 24/48).
  // С Плюсом — новый способ Яндекса (get-file-info): там есть FLAC, приходит зашифрованным, расшифровывает yastream.js.
  // Без входа или без Плюса, или если новый способ не ответил — прежний (MP3 до 320, без входа — 30-секундный фрагмент).
  // preview = true — Яндекс отдал только фрагмент.
  async stream(token, id, q) {
    token = clean(token); q = ['lq', 'nq', 'lossless'].includes(q) ? q : 'lossless';
    if (token && hasPlus !== false) {
      try { return await fileInfo(token, id, q); }
      catch (e) { console.log('[ym] get-file-info', id, '→', e && e.message); }
    }
    const infos = await ym('/tracks/' + id + '/download-info', token);
    const ok = (infos || []).filter((i) => ['mp3', 'aac', 'he-aac'].includes(String(i.codec).toLowerCase()) && i.downloadInfoUrl);
    if (!ok.length) throw new Error('Яндекс не отдал звук для этого трека');
    const cap = q === 'lq' ? 128 : q === 'nq' ? 192 : 999;
    ok.sort((a, b) => ((b.codec === 'mp3') - (a.codec === 'mp3')) || (((b.bitrateInKbps || 0) <= cap) - ((a.bitrateInKbps || 0) <= cap)) || ((b.bitrateInKbps || 0) - (a.bitrateInKbps || 0)));
    const best = ok[0];
    const xml = await raw(best.downloadInfoUrl, token, { text: true });
    const tag = (n) => ((xml.match(new RegExp('<' + n + '>([^<]*)</' + n + '>')) || [])[1] || '');
    const host = tag('host'), path = tag('path'), ts = tag('ts'), s = tag('s');
    if (!host || !path) throw new Error('Не удалось получить ссылку на звук');
    const sign = crypto.createHash('md5').update(SIGN_SALT + path.slice(1) + s).digest('hex');
    const url = ys.add({ urls: ['https://' + host + '/get-mp3/' + sign + '/' + ts + path], codec: best.codec });
    return { url, preview: !!best.preview, bitrate: best.bitrateInKbps, codec: best.codec, quality: q === 'lossless' ? 'hq' : q, lossless: false };
  },
  // текст песни. Порядок: живой текст Яндекса (LRC) → живой из открытой базы LRCLIB → обычный текст Яндекса → обычный из LRCLIB.
  // meta — { title, artist, album, dur } для поиска в LRCLIB. → { synced, lines: [{ t, text }], writers, source } или { none, why }
  async lyrics(token, id, meta = {}) {
    id = String(id).split(':')[0]; token = clean(token);
    const why = [];
    const ya = async (format) => {
      if (!token) throw new Error('нужен вход');
      const ts = Math.floor(Date.now() / 1000);
      const sign = crypto.createHmac('sha256', LYR_KEY).update(id + ts).digest('base64');
      // напрямую, без «запасного» режима: отказ здесь не значит, что токен плохой
      const r = await raw('/tracks/' + id + '/lyrics?format=' + format + '&timeStamp=' + ts + '&sign=' + encodeURIComponent(sign), token);
      if (!r || !r.downloadUrl) throw new Error('нет текста');
      const text = await raw(r.downloadUrl, '', { text: true });
      return { text, writers: (r.writers || []).join(', ') };
    };
    const [yLrc, lib] = await Promise.all([
      ya('LRC').catch((e) => { why.push('Яндекс (живой): ' + errText(e)); return null; }),
      lrclib(meta).catch((e) => { why.push('LRCLIB: ' + errText(e)); return null; }),
    ]);
    const y = yLrc && parseLrc(yLrc.text);
    const l = lib && lib.syncedLyrics && parseLrc(lib.syncedLyrics);
    const hasW = (x) => !!(x && x.some((ln) => ln.w));
    // время по словам важнее: если оно есть только в LRCLIB — берём LRCLIB
    if (hasW(l) && !hasW(y)) return { synced: true, words: true, lines: l, writers: (yLrc && yLrc.writers) || '', source: 'LRCLIB (по словам)' };
    if (y) return { synced: true, words: hasW(y), lines: y, writers: yLrc.writers, source: 'Яндекс Музыка' };
    if (l) return { synced: true, words: hasW(l), lines: l, writers: '', source: 'LRCLIB' };
    if (lib && lib.instrumental) return { none: true, instrumental: true, why: [] };
    const yTxt = await ya('TEXT').catch((e) => { why.push('Яндекс (текст): ' + errText(e)); return null; });
    const plain = (yTxt && yTxt.text.trim() && yTxt) || (lib && lib.plainLyrics && { text: lib.plainLyrics, writers: '' });
    if (plain) return { synced: false, lines: plain.text.split(/\r?\n/).map((text) => ({ t: -1, text: text.trim() })), writers: plain.writers, source: plain === yTxt ? 'Яндекс Музыка' : 'LRCLIB' };
    console.log('[lyrics]', id, why.join(' | '));
    return { none: true, why };
  },
  // ---------- «Мне нравится» в Яндекс Музыке — общее «Любимое» для компьютера и телефона ----------
  // Только с токеном и без запасного «без входа»: эти данные принадлежат аккаунту.
  async likes(token) {
    token = clean(token); if (!token) throw new Error('Нужен вход в Яндекс Музыку');
    const uid = await myUid(token);
    const r = await raw('/users/' + uid + '/likes/tracks', token, { timeout: 20000 });
    const l = (r && r.library && r.library.tracks) || [];
    return { uid, ids: l.map((x) => ({ id: String(x.id).split(':')[0], album: x.albumId ? String(x.albumId) : '', ts: x.timestamp || '' })).filter((x) => /^\d+$/.test(x.id)) };
  },
  // треки по номерам (для лайков, поставленных на другом устройстве), по 100 за запрос
  async tracksById(token, ids) {
    token = clean(token); const out = [];
    for (let i = 0; i < ids.length; i += 100) {
      const part = ids.slice(i, i + 100).join(',');
      const r = await raw('/tracks', token, { method: 'POST', form: { 'track-ids': part, 'with-positions': 'false' }, timeout: 20000 });
      out.push(...tracks(r || []));
    }
    return out;
  },
  // поставить или снять лайк сразу у нескольких треков (ids — «номер:альбом» или «номер»)
  async likeSet(token, ids, on) {
    token = clean(token); if (!token || !ids.length) return true;
    const uid = await myUid(token);
    for (let i = 0; i < ids.length; i += 100) {
      await raw('/users/' + uid + '/likes/tracks/' + (on ? 'add-multiple' : 'remove'), token, { method: 'POST', form: { 'track-ids': ids.slice(i, i + 100).join(',') } });
    }
    return true;
  },
  tokenProblem() { return tokenBad; },
};

// ---------- живые тексты: разбор LRC и открытая база LRCLIB (lrclib.net — без ключей и регистрации) ----------
const errText = (e) => (e && e.status ? 'ответ ' + e.status : '') + (e && e.message && !/^HTTP \d+$/.test(e.message) ? (e.status ? ', ' : '') + e.message : '');
// LRC: «[мм:сс.хх] строка». Расширенный LRC (Enhanced LRC) ещё и со временем каждого слова:
// «[00:12.00] <00:12.10> Что <00:12.40> ты <00:12.62> где-то <00:13.30>» → у строки w: [{ t, s, l }] —
// начало слова (секунды), с какой буквы строки оно начинается и сколько в нём букв; e — когда строка допета.
const ts2s = (m, s) => +m * 60 + parseFloat(String(s).replace(':', '.'));
function parseLrc(text) {
  if (!text || !/\[\d+:\d+/.test(text)) return null;
  const lines = [];
  for (const ln of String(text).split(/\r?\n/)) {
    const tags = [...ln.matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)]; if (!tags.length) continue;
    const body = ln.replace(/\[[^\]]*\]/g, '');
    let w = null, e = 0, plain = body;
    if (/<\d+:\d+(?:[.:]\d+)?>/.test(body)) {
      w = []; plain = '';
      const parts = body.split(/(<\d+:\d+(?:[.:]\d+)?>)/);
      let at = null;
      for (const part of parts) {
        const m = part.match(/^<(\d+):(\d+(?:[.:]\d+)?)>$/);
        if (m) { at = ts2s(m[1], m[2]); e = at; continue; }
        const word = part.replace(/\s+/g, ' ').trim(); if (!word) continue;
        if (plain) plain += ' ';
        if (at != null) w.push({ t: at, s: plain.length, l: word.length });
        plain += word;
      }
      if (!w.length) w = null;
    }
    const t = plain.trim();
    for (const m of tags) lines.push(w ? { t: ts2s(m[1], m[2]), text: t, w, e } : { t: ts2s(m[1], m[2]), text: t });
  }
  lines.sort((a, b) => a.t - b.t);
  return lines.length ? lines : null;
}
const LRCLIB_UA = 'Pulse Desktop (alpha; Windows music player)';
const bare = (s) => String(s || '').replace(/\s*[([].*?[)\]]\s*/g, ' ').replace(/\s+/g, ' ').trim();
async function lrclib({ title, artist, album, dur } = {}) {
  if (!title || !artist) throw new Error('нет названия');
  const get = async (q) => {
    const r = await fetch('https://lrclib.net/api/search?' + new URLSearchParams(q), { headers: { 'User-Agent': LRCLIB_UA }, signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status });
    return r.json();
  };
  let list = await get({ track_name: title, artist_name: artist });
  if (!list.length && bare(title) !== title) list = await get({ track_name: bare(title), artist_name: artist });
  if (!list.length) list = await get({ q: bare(title) + ' ' + artist });
  if (!list.length) throw new Error('не нашлось');
  // ближе всего по длительности; среди близких — с живым текстом
  const d = (x) => (dur ? Math.abs((x.duration || 0) - dur) : 0);
  const ok = list.filter((x) => !dur || d(x) <= 4);
  const pool = ok.length ? ok : list;
  pool.sort((a, b) => (!!b.syncedLyrics - !!a.syncedLyrics) || (d(a) - d(b)));
  return pool[0];
}

module.exports = api;
