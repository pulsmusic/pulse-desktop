// Мост между окном и главным процессом: окно видит только эти функции (без доступа к файлам и системе).
'use strict';
const { contextBridge, ipcRenderer } = require('electron');
const call = (m) => (...a) => ipcRenderer.invoke('ym:' + m, ...a);
contextBridge.exposeInMainWorld('pulse', {
  account: call('account'), search: call('search'), chart: call('chart'), artist: call('artist'), artistInfo: call('artistInfo'),
  album: call('album'), wave: call('wave'), waveFeedback: call('waveFeedback'), stream: call('stream'), lyrics: call('lyrics'),
  openExternal: (u) => ipcRenderer.invoke('open-external', u),
  // токен Яндекс Музыки — из зашифрованного хранилища Windows (читается один раз при запуске), сохраняется туда же
  initialToken: ipcRenderer.sendSync('secret:get'),
  saveToken: (t) => ipcRenderer.invoke('secret:set', t),
  openDevTools: () => ipcRenderer.invoke('dev:devtools'),
  perf: () => ipcRenderer.invoke('perf'),
  perfSlow: (v) => ipcRenderer.invoke('perf:slow', !!v),
  perfUnsafe: () => ipcRenderer.invoke('perf:unsafe'),
  relaunch: () => ipcRenderer.invoke('perf:relaunch'),
  audioCors: (u) => ipcRenderer.invoke('audio:cors', u),
  online: () => ipcRenderer.invoke('online:get'),
  fullscreen: (v) => ipcRenderer.invoke('win:fs', v),
  onFullscreen: (cb) => { const h = (_e, v) => cb(!!v); ipcRenderer.on('win:fs', h); return () => ipcRenderer.removeListener('win:fs', h); },
  aiTimes: (q) => ipcRenderer.invoke('ai:times', q),
  aiState: () => ipcRenderer.invoke('ai:state'),
  aiStatus: (id) => ipcRenderer.invoke('ai:status', id),
  onAiStatus: (cb) => { const h = (_e, st) => cb(st); ipcRenderer.on('ai:status', h); return () => ipcRenderer.removeListener('ai:status', h); },
  onAiDone: (cb) => { const h = (_e, id) => cb(id); ipcRenderer.on('ai:done', h); return () => ipcRenderer.removeListener('ai:done', h); },
  onPower: (cb) => ipcRenderer.on('power', (_e, v) => cb(!!v)),
  // обновления: проверить, поставить (с прогрессом), перезапустить
  update: {
    check: () => ipcRenderer.invoke('upd:check'),
    install: () => ipcRenderer.invoke('upd:install'),
    restart: () => ipcRenderer.invoke('upd:restart'),
    onProgress: (cb) => { const h = (_e, v) => cb(v); ipcRenderer.on('upd:progress', h); return () => ipcRenderer.removeListener('upd:progress', h); },
  },
  version: () => ipcRenderer.invoke('app:version'),
  devUnlock: (pw) => ipcRenderer.invoke('dev:unlock', pw),
  platform: process.platform,
});
