// Пульс для Windows — главный процесс Electron: окно, запросы к Яндекс Музыке, запоминание размера окна.
'use strict';
const { app, BrowserWindow, ipcMain, shell, nativeTheme, powerMonitor } = require('electron');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const ym = require('./yandex');
const upd = require('./updater');
const sec = require('./security');   // базовая защита (см. security.js)

if (!app.requestSingleInstanceLock()) { app.quit(); }

// Плавность на любых мониторах (60 / 120 / 144 / 240 Гц): анимации считает видеокарта.
// Chromium часто «не доверяет» видеокартам ноутбуков и включает программную отрисовку — отсюда ~20 кадров/с.
// Разрешаем видеокарту и растеризацию на ней; частота кадров сама подстраивается под частоту монитора.
// Что узнали о компьютере в прошлый раз (userData/perf.json): если видеокарта уже падала или Chromium отказался
// от неё, больше не заставляем её работать — старые и «капризные» видеокарты так не мигают и не вылетают.
const os = require('os');
const perfFile = () => path.join(app.getPath('userData'), 'perf.json');
let memo = {}; try { memo = JSON.parse(fs.readFileSync(perfFile(), 'utf8')) || {}; } catch {}
const saveMemo = () => { try { fs.mkdirSync(path.dirname(perfFile()), { recursive: true }); fs.writeFileSync(perfFile(), JSON.stringify(memo)); } catch {} };
if (!memo.gpuCrash) {
  app.commandLine.appendSwitch('ignore-gpu-blocklist');
  app.commandLine.appendSwitch('enable-gpu-rasterization');
  app.commandLine.appendSwitch('enable-zero-copy');
  app.commandLine.appendSwitch('enable-features', 'CanvasOopRasterization');
  // Ноутбуки с двумя видеокартами (MacBook Pro с Windows через Boot Camp, игровые ноутбуки): просим систему отдать
  // окно мощной видеокарте — встроенная не тянет размытие стекла на экране с высоким разрешением.
  app.commandLine.appendSwitch('force_high_performance_gpu');
}
// видеокарта упала — запоминаем, со следующего запуска работаем со списком «ненадёжных» видеокарт Chromium
app.on('child-process-gone', (_e, d) => { if (d && d.type === 'GPU' && d.reason !== 'clean-exit' && d.reason !== 'killed') { memo.gpuCrash = (memo.gpuCrash || 0) + 1; saveMemo(); } });
// меньше фоновой работы: проверка орфографии, лишние сетевые службы Chromium программе не нужны
app.commandLine.appendSwitch('disable-features', 'SpareRendererForSitePerProcess,MediaRouter');
app.commandLine.appendSwitch('disable-background-networking');

// ---------- какой компьютер: встроенная / виртуальная видеокарта, MacBook с Windows, работа от батареи ----------
// По этому интерфейс сам выбирает «облегчённые эффекты» (их можно включить или выключить вручную в профиле).
const perf = { tier: 'normal', reasons: [], gpu: '', mac: false, ram: 0, cores: 0, weak: false };
const VENDORS = { 0x8086: 'Intel', 0x1002: 'AMD', 0x10de: 'NVIDIA', 0x1414: 'Microsoft', 0x1ab8: 'Parallels', 0x15ad: 'VMware', 0x80ee: 'VirtualBox', 0x106b: 'Apple', 0x5143: 'Qualcomm' };
async function detectPerf() {
  try {
    const g = await app.getGPUInfo('basic');
    const devs = (g && g.gpuDevice) || []; const act = devs.find((d) => d.active) || devs[0] || {};
    perf.gpu = VENDORS[act.vendorId] || '';
    if (perf.gpu === 'Intel' || perf.gpu === 'Qualcomm') perf.reasons.push('встроенная видеокарта ' + perf.gpu);
    if (['Microsoft', 'Parallels', 'VMware', 'VirtualBox'].includes(perf.gpu)) perf.reasons.push('виртуальная видеокарта (' + perf.gpu + ')');
  } catch {}
  try { const fsx = app.getGPUFeatureStatus(); if (fsx && String(fsx.gpu_compositing || '').startsWith('disabled')) perf.reasons.push('нет ускорения видеокартой'); } catch {}
  if (process.platform === 'win32') {
    await new Promise((res) => execFile('powershell.exe', ['-NoProfile', '-Command', '(Get-CimInstance Win32_ComputerSystem).Manufacturer'], { timeout: 5000, windowsHide: true }, (e, out) => {
      if (!e && /apple/i.test(String(out))) { perf.mac = true; perf.reasons.push('MacBook с Windows'); }
      res();
    }));
  }
  // память и процессор: 4 ГБ и меньше или 2–4 потока — это старый ноутбук/офисный ПК
  perf.ram = Math.round(os.totalmem() / 1073741824); perf.cores = (os.cpus() || []).length;
  if (perf.ram && perf.ram <= 4) perf.reasons.push('мало памяти (' + perf.ram + ' ГБ)');
  if (perf.cores && perf.cores <= 4) perf.reasons.push('процессор на ' + perf.cores + ' потока');
  if (memo.gpuCrash) perf.reasons.push('видеокарта уже давала сбой');
  if (memo.slow) perf.reasons.push('интерфейс шёл медленно в прошлый раз');
  perf.weak = (perf.ram && perf.ram <= 4) || (perf.cores && perf.cores <= 2) || perf.reasons.includes('нет ускорения видеокартой');
  perf.tier = perf.reasons.length ? 'lite' : 'normal';
  return perf;
}
const perfReady = app.whenReady().then(detectPerf);
// интерфейс сам заметил, что кадров мало (или наоборот, всё плавно) — запоминаем на следующий запуск
sec.handle('perf:slow', (_e, v) => { memo.slow = !!v; saveMemo(); return true; });
sec.handle('perf', async () => { await perfReady; let battery = false; try { battery = powerMonitor.isOnBatteryPower(); } catch {} return { ...perf, battery }; });

const stateFile = () => path.join(app.getPath('userData'), 'window.json');
const loadState = () => { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch { return {}; } };

let win = null;
function create() {
  nativeTheme.themeSource = 'dark';
  const st = loadState();
  win = new BrowserWindow({
    width: st.w || 1440, height: st.h || 900, x: st.x, y: st.y, minWidth: 1040, minHeight: 680,
    backgroundColor: '#000000', show: false, title: 'Пульс',
    icon: path.join(__dirname, 'build', 'icon.png'),
    // своя шапка окна: системные кнопки Windows (свернуть / развернуть / закрыть) поверх тёмного фона
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#00000000', symbolColor: '#c7c7cc', height: 40 },
    trafficLightPosition: { x: 24, y: 20 },   // на Mac (для проверки) — кнопки окна внутри бокового меню
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false, backgroundThrottling: true, enableWebSQL: false },
  });
  if (st.max) win.maximize();
  win.loadFile(path.join(__dirname, 'dist', 'index.html'));
  win.once('ready-to-show', () => win.show());
  // от батареи / от сети — интерфейс может облегчить эффекты, чтобы ноутбук не грелся и дольше работал
  const sendPower = (v) => { if (win) win.webContents.send('power', v); };
  powerMonitor.on('on-battery', () => sendPower(true)); powerMonitor.on('on-ac', () => sendPower(false));
  const save = () => { if (!win) return; const b = win.getNormalBounds(); try { fs.writeFileSync(stateFile(), JSON.stringify({ x: b.x, y: b.y, w: b.width, h: b.height, max: win.isMaximized() })); } catch {} };
  win.on('close', save);
  // ссылки наружу — в обычном браузере
  sec.hardenWindow(win);
  win.on('closed', () => { win = null; });
}

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => { sec.setup(); create(); });
app.on('window-all-closed', () => app.quit());

// ---------- мост к Яндекс Музыке ----------
// интерфейс просит: ym:<метод>(токен, ...аргументы) → { ok, v } или { ok: false, error }
const METHODS = ['account', 'search', 'chart', 'artist', 'artistInfo', 'album', 'wave', 'stream', 'lyrics'];
for (const m of METHODS) {
  sec.handle('ym:' + m, async (_e, ...args) => {
    try { return { ok: true, v: await ym[m](...args), tokenProblem: ym.tokenProblem() }; }
    catch (e) { console.log('[ym]', m, '→', e && e.message); return { ok: false, error: String((e && e.message) || e) }; }
  });
}
sec.handle('open-external', (_e, url) => { sec.openExternal(url); });

// ---------- обновления (см. updater.js) ----------
sec.handle('upd:check', async () => {
  try { return { ok: true, v: await upd.check() }; }
  catch (e) { return { ok: false, error: String((e && e.message) || e), nofeed: e && e.code === 'nofeed', current: app.getVersion() }; }
});
let installing = false;
sec.handle('upd:install', async (e) => {
  if (installing) return { ok: false, error: 'Обновление уже ставится' };
  installing = true;
  try { const v = await upd.install((f, label) => { try { e.sender.send('upd:progress', { f, label }); } catch {} }); return { ok: true, v }; }
  catch (er) { return { ok: false, error: String((er && er.message) || er) }; }
  finally { installing = false; }
});
sec.handle('upd:restart', () => { upd.restart(); });
// ---------- режим разработчика ----------
// Пароль в коде не хранится — только его отпечаток PBKDF2-SHA256 (соль + 210 000 повторов): исходники программы
// публичные (обновления на GitHub), поэтому сам пароль из них не достать. После 5 неверных попыток — пауза 60 с.
const DEV = { salt: '27afa81e579664c7131b22f453af8dfd', hash: 'f4c252ebf9b79edb6d829f200965c3cf2421babafddd929f226f16f80d620c0e', iter: 210000 };
let devFails = 0, devLockUntil = 0;
sec.handle('dev:unlock', async (_e, pw) => {
  const now = Date.now();
  if (now < devLockUntil) return { ok: false, wait: Math.ceil((devLockUntil - now) / 1000) };
  const got = await new Promise((res) => require('crypto').pbkdf2(String(pw || ''), Buffer.from(DEV.salt, 'hex'), DEV.iter, 32, 'sha256', (err, k) => res(err ? Buffer.alloc(32) : k)));
  const ok = require('crypto').timingSafeEqual(got, Buffer.from(DEV.hash, 'hex'));
  if (ok) { devFails = 0; sec.setDevOk(true); return { ok: true }; }
  if (++devFails >= 5) { devFails = 0; devLockUntil = now + 60000; return { ok: false, wait: 60 }; }
  return { ok: false, left: 5 - devFails };
});
sec.handle('app:version', () => ({ version: app.getVersion(), electron: process.versions.electron, packaged: app.isPackaged }));
