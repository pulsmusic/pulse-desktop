// Звук Яндекса через саму программу: адрес pulseya://s/<id>.
// • Без потерь (FLAC) Яндекс отдаёт зашифрованным (AES-CTR, ключ приходит вместе со ссылкой под токен пользователя) —
//   здесь он расшифровывается на лету, кусками, по мере того как плеер просит данные. На диск ничего не пишется.
// • Обычные ссылки тоже идут через эту схему: окно всегда может подключить к звуку эквалайзер (Web Audio),
//   не завися от того, разрешает ли сервер Яндекса чтение звука странице (CORS).
// Перемотка работает: плеер просит кусок с любого места, счётчик AES-CTR сдвигается на нужный блок.
'use strict';
const crypto = require('crypto');

const reg = new Map();   // id → { urls, key, type, t }
const LIFE = 6 * 3600 * 1000, MAX = 300;
const TYPE = { flac: 'audio/flac', 'flac-mp4': 'audio/mp4', mp3: 'audio/mpeg', aac: 'audio/mp4', 'he-aac': 'audio/mp4', 'aac-mp4': 'audio/mp4', 'he-aac-mp4': 'audio/mp4' };
const yandexHost = (u) => { try { const x = new URL(u); return x.protocol === 'https:' && /(^|\.)(yandex\.(net|ru|com)|yastatic\.net)$/.test(x.hostname); } catch { return false; } };

// ссылки (и ключ, если звук зашифрован) → адрес для плеера
function add({ urls, key, codec }) {
  urls = [].concat(urls || []).filter(yandexHost);
  if (!urls.length) throw new Error('Нет ссылки на звук');
  const now = Date.now();
  for (const [k, v] of reg) if (now - v.t > LIFE || reg.size > MAX) reg.delete(k); else break;
  const id = crypto.randomBytes(12).toString('hex');
  reg.set(id, { urls, key: key && /^[0-9a-f]{32}([0-9a-f]{32})?$/i.test(key) ? Buffer.from(key, 'hex') : null, type: TYPE[String(codec || '').toLowerCase()] || 'audio/mpeg', t: now });
  return 'pulseya://s/' + id;
}

// расшифровщик с нужного места: блок AES — 16 байт, счётчик — номер блока (как у Яндекса: nonce из нулей)
function decipherAt(key, pos) {
  const iv = Buffer.alloc(16); iv.writeBigUInt64BE(BigInt(Math.floor(pos / 16)), 8);
  const d = crypto.createDecipheriv(key.length === 32 ? 'aes-256-ctr' : 'aes-128-ctr', key, iv);
  const skip = pos % 16; if (skip) d.update(Buffer.alloc(skip));
  return d;
}

const H = (extra) => ({ 'access-control-allow-origin': '*', 'cache-control': 'no-store', 'accept-ranges': 'bytes', ...extra });
async function serve(req) {
  let u; try { u = new URL(req.url); } catch { return new Response(null, { status: 400, headers: H() }); }
  const e = u.hostname === 's' && reg.get(u.pathname.replace(/^\/+/, ''));
  if (!e) return new Response(null, { status: 404, headers: H() });
  const range = req.headers.get('range') || '';
  let up = null, lastErr = null;
  for (const src of e.urls) {
    try {
      up = await fetch(src, { headers: range ? { Range: range } : {}, redirect: 'follow', signal: AbortSignal.timeout(20000) });
      if (up.ok || up.status === 206) break;
      lastErr = new Error('HTTP ' + up.status); try { up.body && up.body.cancel(); } catch {} up = null;
    } catch (er) { lastErr = er; up = null; }
  }
  if (!up) { if (up === null && lastErr) console.log('[yastream]', lastErr.message); return new Response(null, { status: 502, headers: H() }); }
  if (up.status === 416) return new Response(null, { status: 416, headers: H({ 'content-range': up.headers.get('content-range') || '' }) });
  const cr = up.headers.get('content-range') || '';
  const start = up.status === 206 ? +((/bytes (\d+)-/.exec(cr) || [])[1] || 0) : 0;
  const len = up.headers.get('content-length');
  const out = H({ 'content-type': e.type, ...(len ? { 'content-length': len } : {}), ...(up.status === 206 && cr ? { 'content-range': cr } : {}) });
  if (!e.key) return new Response(up.body, { status: up.status, headers: out });
  const dec = decipherAt(e.key, start); const rd = up.body.getReader();
  const body = new ReadableStream({
    async pull(c) {
      try {
        const { done, value } = await rd.read();
        if (done) { const f = dec.final(); if (f.length) c.enqueue(new Uint8Array(f)); c.close(); return; }
        const b = dec.update(Buffer.from(value.buffer, value.byteOffset, value.byteLength)); c.enqueue(new Uint8Array(b.buffer, b.byteOffset, b.length));
      } catch (er) { c.error(er); }
    },
    cancel() { rd.cancel().catch(() => {}); },
  });
  return new Response(body, { status: up.status, headers: out });
}

function setup(protocol, log) {
  protocol.handle('pulseya', (req) => serve(req).catch((er) => { (log || console.log)('звук Яндекса: отдача', er && er.message); return new Response(null, { status: 500, headers: H() }); }));
}
module.exports = { add, setup, decipherAt, serve };
