// Обновления «Пульса» для Windows и Mac — без переустановки.
//
// На Mac (запуск через boot.js) файлы программы не пишутся внутрь Pulse.app (это сломало бы её подпись): новая
// версия кладётся в ~/Library/Application Support/Pulse/ota/<версия>/, и загрузчик запускает её. Если новой версии
// нужен другой движок (Electron), скачивается целиком новая Pulse.app для этого Mac (Apple M или Intel, ~100 МБ;
// адрес и SHA-256 — в mac.json того же релиза), распаковывается рядом со старой, проверяется её подпись, и после
// выхода из программы маленький скрипт меняет старую Pulse.app на новую и запускает её. Вход и настройки не трогаются.
//
// Откуда: релизы GitHub репозитория pulsmusic/pulse-desktop. В каждом релизе — файл latest.json (какая версия,
// что нового, ссылка на пакет и его контрольная сумма SHA-256) и сам пакет pulse-app-<версия>.zip (~0,7 МБ):
// только файлы «Пульса» (main.js, preload.js, yandex.js, updater.js, package.json, dist/, build/icon.png).
// Electron (основа программы, ~110 МБ) не скачивается — он уже установлен. Если новой версии нужен другой Electron,
// latest.json говорит об этом (minElectron), и программа предложит скачать новый установщик.
//
// Как ставится: пакет скачивается во временную папку, сверяется по SHA-256, распаковывается и проверяется
// (есть main.js, интерфейс, версия совпадает). Текущие файлы копируются в резервную папку
// (%APPDATA%\Pulse\update-backup), новые записываются на их место, и программа перезапускается.
// Токен, лайки и настройки не трогаются — они хранятся отдельно (%APPDATA%\Pulse).
'use strict';
const { app } = require('electron');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const os = require('os');
const { execFile, spawn } = require('child_process');
const BOOT = global.__pulseBoot || null;   // запущены через загрузчик Mac (boot.js)

const FEED = process.env.PULSE_UPDATE_FEED || 'https://github.com/pulsmusic/pulse-desktop/releases/latest/download/latest.json';
const RELEASES = 'https://github.com/pulsmusic/pulse-desktop/releases/latest';

// «0.9.10» > «0.9.9»
function newer(a, b) {
  const pa = String(a).split(/[.-]/).map((x) => parseInt(x, 10) || 0), pb = String(b).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}

// GitHub иногда на минуту отвечает 502/503 — повторяем, а потом спрашиваем через API GitHub (другой путь к тому же файлу)
const API_LATEST = 'https://api.github.com/repos/pulsmusic/pulse-desktop/releases/latest';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
async function getOnce(url, accept) {
  const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { headers: { 'User-Agent': 'PulseDesktop/' + app.getVersion(), Accept: accept || 'application/json' }, signal: AbortSignal.timeout(15000), redirect: 'follow' });
  if (r.status === 404) throw Object.assign(new Error('Обновлений пока не выкладывали'), { code: 'nofeed' });
  if (!r.ok) throw Object.assign(new Error('Сервер обновлений ответил ' + r.status), { status: r.status });
  return r.json();
}
async function viaApi() {
  const rel = await getOnce(API_LATEST, 'application/vnd.github+json');
  const a = (rel.assets || []).find((x) => x.name === 'latest.json');
  if (!a) throw Object.assign(new Error('Обновлений пока не выкладывали'), { code: 'nofeed' });
  return getOnce(a.url, 'application/octet-stream');
}
async function getJSON(url) {
  let err = null;
  for (let i = 0; i < 3; i++) {
    try { return await getOnce(url); }
    catch (e) { err = e; if (e.code === 'nofeed' || (e.status && e.status < 500 && e.status !== 429)) throw e; await wait(800 * (i + 1)); }
  }
  if (url === FEED && !process.env.PULSE_UPDATE_FEED) { try { return await viaApi(); } catch (e) { if (e.code === 'nofeed') throw e; } }
  throw new Error(err && err.status ? 'GitHub, где лежат обновления, временно не отвечает (' + err.status + '). Попробуйте через пару минут' : 'Нет связи с сервером обновлений. Проверьте интернет');
}

let latest = null;   // последний прочитанный latest.json

// Скачивание файла релиза. GitHub иногда на минуту отвечает 502/503/504 — повторяем с паузой (1,5 → 3 → 6 с),
// а если не помогло — берём тот же файл через API GitHub (другой адрес, тот же файл; сверка SHA-256 всё равно ниже).
async function download(url, ms) {
  const ua = { 'User-Agent': 'PulseDesktop/' + app.getVersion() };
  let last = null;
  for (let i = 0; i < 4; i++) {
    try {
      const r = await fetch(url, { headers: ua, redirect: 'follow', signal: AbortSignal.timeout(ms) });
      if (r.ok && r.body) return r;
      last = r.status;
      if (r.status < 500 && r.status !== 429) break;
    } catch (e) { last = e; }
    await wait(1500 * 2 ** i);
  }
  // запасной путь: …/releases/download/v<версия>/<файл> → API: релиз по тегу → файл по id
  const m = /^https:\/\/github\.com\/([^/]+\/[^/]+)\/releases\/download\/([^/]+)\/([^/?#]+)$/.exec(String(url));
  if (m) {
    try {
      const rel = await getOnce('https://api.github.com/repos/' + m[1] + '/releases/tags/' + m[2], 'application/vnd.github+json');
      const a = (rel.assets || []).find((x) => x.name === decodeURIComponent(m[3]));
      if (a) { const r = await fetch(a.url, { headers: { ...ua, Accept: 'application/octet-stream' }, redirect: 'follow', signal: AbortSignal.timeout(ms) }); if (r.ok && r.body) return r; last = r.status; }
    } catch (e) { last = last || e; }
  }
  throw new Error(typeof last === 'number' && last >= 500 ? 'GitHub, где лежат обновления, временно не отдаёт файл (' + last + '). Попробуйте ещё раз через минуту' : 'Не получилось скачать обновление' + (typeof last === 'number' ? ' (ответ ' + last + ')' : '. Проверьте интернет'));
}

const needEngine = (m) => !!(m && m.minElectron && newer(m.minElectron, process.versions.electron));

async function check() {
  const cur = app.getVersion();
  const m = await getJSON(FEED);
  if (!m || !m.version || !m.url || !/^[0-9a-f]{64}$/i.test(String(m.sha256 || ''))) throw new Error('Файл обновлений повреждён');
  latest = m;
  // версия, которая на этом Mac уже не запустилась и была откачена, больше не предлагается
  const available = newer(m.version, cur) && !(BOOT && (otaState().bad || []).includes(m.version));
  const mac = process.platform === 'darwin';
  let needInstaller = false, engine = false, size = m.size || 0, why = '';
  if (mac && !BOOT) { needInstaller = true; why = 'old-mac'; }   // старая сборка для Mac без загрузчика — один раз поставить заново
  else if (needEngine(m)) {
    if (BOOT && available) {
      // новый движок на Mac — тоже по воздуху (если сборки для Mac в релизе ещё нет — через сайт)
      try { const e = await macEngine(m); engine = true; size = e.size; } catch (er) { needInstaller = true; why = String(er.message || er); }
    } else if (!BOOT) needInstaller = true;
  }
  return { current: cur, version: m.version, available, notes: Array.isArray(m.notes) ? m.notes.slice(0, 12) : [], size,
    date: m.date || '', needInstaller, engine, why, installer: mac ? RELEASES : m.installer || RELEASES, packaged: app.isPackaged };
}

// ---------- Mac: новая Pulse.app целиком (когда меняется движок) ----------
// mac.json лежит в том же релизе, что и latest.json: { version, electron, arm64: { url, sha256, size }, x64: {…} }
async function macEngine(m) {
  const u = new URL('mac.json', m.url).href;
  const j = await getJSON(u).catch(() => { throw new Error('Сборка для Mac этой версии ещё готовится — попробуйте через несколько минут'); });
  const a = j && j[process.arch];
  if (!j || j.version !== m.version || !a || !a.url || !/^[0-9a-f]{64}$/i.test(String(a.sha256 || '')) || !(a.size > 0)) throw new Error('Сборка для Mac этой версии ещё готовится — попробуйте через несколько минут');
  if (!process.env.PULSE_UPDATE_FEED && !String(a.url).startsWith(PKG_PREFIX)) throw new Error('Адрес сборки для Mac не похож на релиз «Пульса» — обновление отменено');
  return a;
}
const run = (cmd, args) => new Promise((res, rej) => execFile(cmd, args, { timeout: 180000, maxBuffer: 4 << 20 }, (e, out, err) => (e ? rej(new Error(String(err || e.message).trim().split('\n').pop())) : res(out))));
let swap = null;   // готовая к замене Pulse.app: { from, to, work, admin }

async function installEngine(m, progress) {
  const e = await macEngine(m);
  const appPath = path.resolve(process.execPath, '..', '..', '..');
  if (!/\.app$/.test(appPath)) throw new Error('Не нашёл саму программу Pulse.app');
  if (/AppTranslocation/.test(appPath)) throw new Error('Перенесите «Пульс» в папку «Программы», откройте его оттуда и обновите ещё раз');
  if (/['"\\]/.test(appPath)) throw new Error('В пути к программе есть кавычки — перенесите «Пульс» в папку «Программы»');
  let admin = false;
  try { fs.accessSync(path.dirname(appPath), fs.constants.W_OK); fs.accessSync(appPath, fs.constants.W_OK); } catch { admin = true; }
  // распаковываем рядом со старой программой (тот же диск — замена мгновенная); нет прав — во временную папку
  const work = admin ? path.join(os.tmpdir(), 'pulse-update-' + m.version) : path.join(path.dirname(appPath), '.pulse-update');
  fs.rmSync(work, { recursive: true, force: true }); fs.mkdirSync(work, { recursive: true });
  const zip = path.join(work, 'engine.zip');
  progress(0, 'Скачиваю версию ' + m.version + ' с новым движком');
  const r = await download(e.url, 15 * 60000);
  const h = crypto.createHash('sha256'); const fd = fs.openSync(zip, 'w'); let got = 0;
  try {
    for await (const chunk of r.body) { const b = Buffer.from(chunk); h.update(b); fs.writeSync(fd, b); got += b.length; progress(Math.min(0.8, (got / e.size) * 0.8), 'Скачиваю версию ' + m.version + ' с новым движком'); }
  } finally { fs.closeSync(fd); }
  if (got !== e.size || h.digest('hex') !== String(e.sha256).toLowerCase()) { fs.rmSync(work, { recursive: true, force: true }); throw new Error('Обновление скачалось с ошибкой (не совпала контрольная сумма). Попробуйте ещё раз.'); }
  progress(0.84, 'Распаковываю');
  const out = path.join(work, 'new');
  await run('/usr/bin/ditto', ['-x', '-k', zip, out]);
  fs.rmSync(zip, { force: true });
  const nu = path.join(out, 'Pulse.app');
  progress(0.92, 'Проверяю подпись');
  let pkg = {}; try { pkg = JSON.parse(fs.readFileSync(path.join(nu, 'Contents', 'Resources', 'app', 'package.json'), 'utf8')); } catch {}
  if (pkg.version !== m.version) { fs.rmSync(work, { recursive: true, force: true }); throw new Error('Версия в скачанной программе не совпадает с объявленной'); }
  await run('/usr/bin/xattr', ['-cr', nu]).catch(() => {});
  try { await run('/usr/bin/codesign', ['--verify', '--deep', nu]); }
  catch (er) { fs.rmSync(work, { recursive: true, force: true }); throw new Error('Подпись скачанной программы не сошлась: ' + er.message); }
  swap = { from: nu, to: appPath, work, admin };
  progress(1, admin ? 'Перезапуск — macOS попросит пароль, чтобы заменить программу' : 'Перезапускаю');
  return { version: m.version, engine: true, admin };
}

// скрипт замены: ждёт выхода «Пульса», меняет Pulse.app (не вышло — возвращает старую) и запускает программу
const SWAP_SH = `#!/bin/sh
MODE="$1"; PID="$2"; OLD="$3"; NEW="$4"; WORK="$5"
core() {
  BAK="$WORK/old.app"; rm -rf "$BAK"
  if mv "$OLD" "$BAK"; then
    if mv "$NEW" "$OLD"; then rm -rf "$BAK"; else mv "$BAK" "$OLD"; fi
  fi
}
if [ "$MODE" = core ]; then core; exit 0; fi
i=0; while kill -0 "$PID" 2>/dev/null && [ $i -lt 300 ]; do sleep 0.1; i=$((i+1)); done
if [ "$MODE" = admin ]; then
  /usr/bin/osascript -e "do shell script \\"/bin/sh '$0' core 0 '$OLD' '$NEW' '$WORK'\\" with administrator privileges" || true
else core; fi
rm -rf "$WORK"
/usr/bin/open "$OLD"
`;
function startSwap() {
  const sh = path.join(os.tmpdir(), 'pulse-swap-' + process.pid + '.sh');
  fs.writeFileSync(sh, SWAP_SH, { mode: 0o700 });
  const p = spawn('/bin/sh', [sh, swap.admin ? 'admin' : 'user', String(process.pid), swap.to, swap.from, swap.work], { detached: true, stdio: 'ignore' });
  p.unref();
}

// ---------- Mac: обычное обновление — в папку пользователя ----------
function otaState() { try { return JSON.parse(fs.readFileSync(path.join(BOOT.ota, 'state.json'), 'utf8')) || {}; } catch { return {}; } }
function placeOta(files, ver) {
  const dir = path.join(BOOT.ota, ver), tmp = dir + '.part';
  fs.rmSync(tmp, { recursive: true, force: true });
  for (const f of files) { const to = path.join(tmp, f.name); fs.mkdirSync(path.dirname(to), { recursive: true }); fs.writeFileSync(to, f.data); }
  fs.rmSync(dir, { recursive: true, force: true }); fs.renameSync(tmp, dir);
  const s = otaState();
  // предыдущая рабочая версия остаётся на случай, если новая не запустится
  const prev = BOOT.fromOta && BOOT.version !== ver ? BOOT.version : '';
  const ns = { current: ver, previous: prev, tries: 0, bad: (s.bad || []).filter((x) => x !== ver) };
  fs.writeFileSync(path.join(BOOT.ota, 'state.json'), JSON.stringify(ns));
  try { for (const d of fs.readdirSync(BOOT.ota)) if (/^[\d.]+(\.part)?$/.test(d) && d !== ver && d !== prev) fs.rmSync(path.join(BOOT.ota, d), { recursive: true, force: true }); } catch {}
}

// ---------- распаковка zip без сторонних библиотек ----------
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('пакет обновления повреждён (не zip)');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('пакет обновления повреждён');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl);
    p += 46 + nl + xl + cl;
    if (name.endsWith('/')) continue;
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('пакет обновления повреждён');
    const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28);
    const raw = buf.subarray(start, start + csize);
    const data = method === 0 ? Buffer.from(raw) : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data) throw new Error('пакет обновления сжат неизвестным способом');
    if (data.length !== usize) throw new Error('пакет обновления повреждён (размер)');
    // только безопасные пути внутри папки программы
    const rel = path.normalize(name).replace(/^([/\\])+/, '');
    if (rel.startsWith('..') || path.isAbsolute(rel)) continue;
    out.push({ name: rel, data });
  }
  return out;
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}

// progress(доля 0…1, подпись)
// пакет скачивается только из релизов «Пульса» на GitHub (кроме проверки с подменённым адресом PULSE_UPDATE_FEED)
const PKG_PREFIX = 'https://github.com/pulsmusic/pulse-desktop/releases/download/';
async function install(progress) {
  if (process.platform === 'darwin' && !BOOT) throw new Error('Эту сборку для Mac нужно один раз поставить заново со страницы релиза «Пульса» — дальше обновления придут сами');
  if (!process.env.PULSE_UPDATE_FEED && latest && !String(latest.url).startsWith(PKG_PREFIX)) throw new Error('Адрес пакета обновления не похож на релиз «Пульса» — обновление отменено');
  if (!app.isPackaged) throw new Error('Обновления ставятся только в установленный «Пульс» (через установщик). Сейчас программа запущена для проверки.');
  // Перед скачиванием всегда заново читаем latest.json: если пока программа ждала, вышло ещё несколько версий,
  // ставится сразу самая последняя (пакет — полная программа, промежуточные версии не нужны).
  progress(0, 'Проверяю последнюю версию');
  let m = latest;
  try {
    const f = await getJSON(FEED);
    if (f && f.version && f.url && /^[0-9a-f]{64}$/i.test(String(f.sha256 || '')) && (!m || !newer(m.version, f.version))) m = f;
  } catch (e) { if (!m) throw e; }
  if (!newer(m.version, app.getVersion())) throw new Error('У вас уже последняя версия');
  latest = m;
  if (!process.env.PULSE_UPDATE_FEED && !String(m.url).startsWith(PKG_PREFIX)) throw new Error('Адрес пакета обновления не похож на релиз «Пульса» — обновление отменено');
  if (needEngine(m)) { if (BOOT) return installEngine(m, progress); throw new Error('Для этой версии нужен новый установщик'); }
  progress(0, 'Скачиваю версию ' + m.version);
  const r = await download(m.url, 120000);
  const total = Number(r.headers.get('content-length')) || m.size || 0; const parts = []; let got = 0;
  for await (const chunk of r.body) { parts.push(Buffer.from(chunk)); got += chunk.length; if (total) progress(Math.min(0.85, (got / total) * 0.85), 'Скачиваю версию ' + m.version); }
  const buf = Buffer.concat(parts);
  const sum = crypto.createHash('sha256').update(buf).digest('hex');
  if (sum.toLowerCase() !== String(m.sha256).toLowerCase()) throw new Error('Обновление скачалось с ошибкой (не совпала контрольная сумма). Попробуйте ещё раз.');
  progress(0.88, 'Проверяю файлы');
  const files = readZip(buf);
  const has = (n) => files.some((f) => f.name.replace(/\\/g, '/') === n);
  if (!has('main.js') || !has('preload.js') || !has('dist/index.html') || !has('package.json') || !has('security.js') || !has('online.js')) throw new Error('В пакете обновления не хватает файлов');
  const pkg = JSON.parse(files.find((f) => f.name === 'package.json').data.toString('utf8'));
  if (pkg.version !== m.version) throw new Error('Версия в пакете не совпадает с объявленной');

  if (BOOT) {   // Mac: рядом, в папку пользователя
    progress(0.96, 'Ставлю обновление');
    try { placeOta(files, m.version); } catch (e) { throw new Error('Не получилось записать файлы обновления: ' + e.message); }
    progress(1, 'Перезапускаю');
    return { version: m.version };
  }
  // резервная копия текущей версии, затем запись новой
  const appDir = app.getAppPath();
  const backup = path.join(app.getPath('userData'), 'update-backup');
  progress(0.92, 'Сохраняю резервную копию');
  fs.rmSync(backup, { recursive: true, force: true });
  copyDir(appDir, backup);
  progress(0.96, 'Ставлю обновление');
  try {
    fs.rmSync(path.join(appDir, 'dist'), { recursive: true, force: true });   // старые файлы интерфейса не смешиваются с новыми
    for (const f of files) {
      const to = path.join(appDir, f.name);
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.writeFileSync(to, f.data);
    }
  } catch (e) {
    // не получилось — возвращаем как было
    try { copyDir(backup, appDir); } catch {}
    throw new Error('Не получилось записать файлы обновления: ' + e.message);
  }
  progress(1, 'Перезапускаю');
  return { version: m.version };
}

function restart() { if (swap) { startSwap(); app.exit(0); return; } app.relaunch(); app.exit(0); }

module.exports = { check, install, restart, newer, readZip, FEED };
