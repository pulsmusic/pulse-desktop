// Пульс для Windows — клиент Яндекс Музыки (работает в главном процессе Electron, на Node.js).
// Тот же неофициальный API, что и у библиотеки MarshalX/yandex-music-api (её использует сервер телефонной версии),
// только переписанный на JavaScript — поэтому на компьютере отдельный сервер не нужен.
// Токен пользователя хранится только на этом компьютере и уходит только на api.music.yandex.net.
'use strict';
const crypto = require('crypto');

const BASE = 'https://api.music.yandex.net';
const SIGN_SALT = 'XGRlBW9FXlekgbPrRHuSiA';   // соль подписи ссылки на mp3 (как в yandex_music/download_info.py)
const LYR_KEY = 'p93jhgh689SBReK6ghtw62';      // ключ подписи запроса текста (как в yandex_music/utils/sign_request.py)
const HEAD = { 'X-Yandex-Music-Client': 'YandexMusicAndroid/24023621', 'Accept-Language': 'ru', 'User-Agent': 'Yandex-Music-API' };

let tokenBad = '';   // причина, если токен не подошёл (видно в настройках)

const clean = (t) => {
  t = String(t || '').trim();
  if (t.includes('access_token=')) t = t.split('access_token=')[1];
  return t.split('&')[0].trim();
};

// токен уходит только на серверы Яндекса — даже если какой-то ответ подсунет ссылку на чужой сайт
const yandexHost = (u) => { try { const h = new URL(u).hostname; return /(^|\.)yandex\.(net|ru|com)$/.test(h); } catch { return false; } };
async function raw(path, token, opt = {}) {
  if (token && path.startsWith('http') && !yandexHost(path)) token = '';
  const headers = { ...HEAD };
  if (token) headers.Authorization = 'OAuth ' + token;
  if (opt.form) headers['Content-Type'] = 'application/x-www-form-urlencoded';
  const r = await fetch(path.startsWith('http') ? path : BASE + path, {
    method: opt.method || 'GET', headers, body: opt.form ? new URLSearchParams(opt.form).toString() : undefined,
    signal: AbortSignal.timeout(15000),
  });
  const text = await r.text();
  if (opt.text) { if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status }); return text; }
  let d = null; try { d = JSON.parse(text); } catch { /* не JSON */ }
  if (!r.ok) {
    const e = new Error((d && d.error && (d.error.message || d.error.name)) || 'Яндекс ответил ' + r.status);
    e.status = r.status; throw e;
  }
  return d ? d.result : null;
}

// запрос с токеном; если токен не подошёл (401/403) — повторяем без него, приложение продолжает работать
async function ym(path, token, opt) {
  token = clean(token);
  if (!token) return raw(path, '', opt);
  try { const v = await raw(path, token, opt); tokenBad = ''; return v; }
  catch (e) {
    if (e.status === 401 || e.status === 403) { tokenBad = 'Токен не подошёл (' + e.status + '). Работаю без входа — 30-секундные фрагменты'; return raw(path, '', opt); }
    throw e;
  }
}

// ---------- перевод в простой вид для интерфейса ----------
const cover = (u, s = '400x400') => (u ? 'https://' + String(u).replace('%%', s) : '');
function track(t) {
  if (!t || t.available === false || !t.title) return null;
  const al = (t.albums || [])[0];
  return {
    id: String(t.id),
    title: t.title + (t.version ? ' (' + t.version + ')' : ''),
    artist: (t.artists || []).map((a) => a.name).filter(Boolean).join(', '),
    artists: (t.artists || []).map((a) => ({ id: String(a.id), name: a.name })),
    album: al ? { id: String(al.id), title: al.title, year: al.year } : null,
    cover: cover(t.coverUri || (al && al.coverUri)),
    coverBig: cover(t.coverUri || (al && al.coverUri), '1000x1000'),
    dur: Math.round((t.durationMs || 0) / 1000),
    explicit: t.contentWarning === 'explicit',
    genre: (al && al.genre) || '',
    // есть ли у трека текст: 2 — живой (строки с таймкодами), 1 — только текст, 0 — нет, null — Яндекс не сказал
    lyrics: t.lyricsInfo ? (t.lyricsInfo.hasAvailableSyncLyrics ? 2 : t.lyricsInfo.hasAvailableTextLyrics ? 1 : 0) : null,
  };
}
const tracks = (l) => (l || []).map(track).filter(Boolean);
const artist = (a) => (a ? { id: String(a.id), name: a.name, photo: cover((a.cover && a.cover.uri) || a.ogImage), genres: a.genres || [] } : null);
const album = (a) => (a ? {
  id: String(a.id), title: a.title, artist: (a.artists || []).map((x) => x.name).join(', '),
  artistId: a.artists && a.artists[0] ? String(a.artists[0].id) : '', cover: cover(a.coverUri), coverBig: cover(a.coverUri, '1000x1000'),
  year: a.year || null, type: a.type || 'album', count: a.trackCount || 0,
} : null);

// ---------- точки API ----------
const api = {
  async account(token) {
    token = clean(token);
    if (!token) return { auth: false };
    try {
      const r = await raw('/account/status', token);
      tokenBad = '';
      return { auth: true, login: (r.account && (r.account.displayName || r.account.login)) || '', plus: !!(r.plus && r.plus.hasPlus) };
    } catch (e) { tokenBad = 'Токен не подошёл: ' + e.message; return { auth: false, error: tokenBad }; }
  },
  async search(token, q) {
    const r = await ym('/search?text=' + encodeURIComponent(q) + '&type=all&page=0&nocorrect=false', token);
    return {
      tracks: tracks(r && r.tracks && r.tracks.results).slice(0, 30),
      artists: ((r && r.artists && r.artists.results) || []).map(artist).filter(Boolean).slice(0, 12),
      albums: ((r && r.albums && r.albums.results) || []).map(album).filter(Boolean).slice(0, 12),
    };
  },
  async chart(token) {
    const r = await ym('/landing3/chart/russia', token);
    return tracks(((r && r.chart && r.chart.tracks) || []).map((x) => x.track)).slice(0, 50);
  },
  async artist(token, id) {
    const [bi, tr] = await Promise.all([
      ym('/artists/' + id + '/brief-info', token),
      ym('/artists/' + id + '/tracks?page-size=50', token).catch(() => null),
    ]);
    const al = await ym('/artists/' + id + '/direct-albums?page-size=50&sort-by=year', token).catch(() => null);
    const a0 = bi && bi.artist; const info = artist(a0);
    if (info) {
      const d = a0.description;
      info.description = (d && (d.text || d)) || '';
      if (typeof info.description !== 'string') info.description = '';
      info.counts = a0.counts || {};
      info.countries = a0.countries || [];
      // настоящая статистика Яндекс Музыки (brief-info): слушатели за месяц и их прирост, лайки исполнителя,
      // число треков и альбомов во всём каталоге (а не только загруженных 50)
      const st = bi.stats || {};
      info.listeners = st.lastMonthListeners || 0;
      info.listenersDelta = st.lastMonthListenersDelta || 0;
      info.likes = a0.likesCount || 0;
      info.ratingMonth = (a0.ratings && a0.ratings.month) || 0;
      info.photoBig = cover((a0.cover && a0.cover.uri) || a0.ogImage, '1000x1000');
      const all = (al && al.albums) || [];   // год первого релиза — только если список альбомов полный
      const years = all.length < 50 ? all.map((x) => x.year).filter((y) => y > 1900) : [];
      info.firstYear = years.length ? Math.min(...years) : 0;
    }
    return {
      info,
      tracks: tracks((tr && tr.tracks) || (bi && bi.popularTracks)),
      albums: ((al && al.albums) || (bi && bi.albums) || []).map(album).filter(Boolean),
      similar: ((bi && bi.similarArtists) || []).map(artist).filter(Boolean).slice(0, 12),
    };
  },
  async artistInfo(token, id) {
    const bi = await ym('/artists/' + id + '/brief-info', token);
    return artist(bi && bi.artist);
  },
  async album(token, id) {
    const a = await ym('/albums/' + id + '/with-tracks', token);
    return { info: album(a), tracks: tracks([].concat(...((a && a.volumes) || []))) };
  },
  // «Моя волна» — персональный бесконечный поток Яндекса (нужен вход)
  async wave(token, after) {
    if (!clean(token)) return { tracks: [], need: 'token' };
    const r = await ym('/rotor/station/user:onyourwave/tracks?settings2=true' + (after ? '&queue=' + encodeURIComponent(after) : ''), token);
    return { tracks: tracks(((r && r.sequence) || []).map((x) => x.track)) };
  },
  // прямая ссылка на звук. preview = true — Яндекс отдал только фрагмент (без входа или без Плюса)
  async stream(token, id) {
    const infos = await ym('/tracks/' + id + '/download-info', token);
    const ok = (infos || []).filter((i) => ['mp3', 'aac', 'he-aac'].includes(String(i.codec).toLowerCase()) && i.downloadInfoUrl);
    if (!ok.length) throw new Error('Яндекс не отдал звук для этого трека');
    ok.sort((a, b) => ((b.codec === 'mp3') - (a.codec === 'mp3')) || ((b.bitrateInKbps || 0) - (a.bitrateInKbps || 0)));
    const best = ok[0];
    const xml = await raw(best.downloadInfoUrl, clean(token), { text: true });
    const tag = (n) => ((xml.match(new RegExp('<' + n + '>([^<]*)</' + n + '>')) || [])[1] || '');
    const host = tag('host'), path = tag('path'), ts = tag('ts'), s = tag('s');
    if (!host || !path) throw new Error('Не удалось получить ссылку на звук');
    const sign = crypto.createHash('md5').update(SIGN_SALT + path.slice(1) + s).digest('hex');
    return { url: 'https://' + host + '/get-mp3/' + sign + '/' + ts + path, preview: !!best.preview, bitrate: best.bitrateInKbps, codec: best.codec };
  },
  // текст песни. Порядок: живой текст Яндекса (LRC) → живой из открытой базы LRCLIB → обычный текст Яндекса → обычный из LRCLIB.
  // meta — { title, artist, album, dur } для поиска в LRCLIB. → { synced, lines: [{ t, text }], writers, source } или { none, why }
  async lyrics(token, id, meta = {}) {
    id = String(id).split(':')[0]; token = clean(token);
    const why = [];
    const ya = async (format) => {
      if (!token) throw new Error('нужен вход');
      const ts = Math.floor(Date.now() / 1000);
      const sign = crypto.createHmac('sha256', LYR_KEY).update(id + ts).digest('base64');
      // напрямую, без «запасного» режима: отказ здесь не значит, что токен плохой
      const r = await raw('/tracks/' + id + '/lyrics?format=' + format + '&timeStamp=' + ts + '&sign=' + encodeURIComponent(sign), token);
      if (!r || !r.downloadUrl) throw new Error('нет текста');
      const text = await raw(r.downloadUrl, '', { text: true });
      return { text, writers: (r.writers || []).join(', ') };
    };
    const [yLrc, lib] = await Promise.all([
      ya('LRC').catch((e) => { why.push('Яндекс (живой): ' + errText(e)); return null; }),
      lrclib(meta).catch((e) => { why.push('LRCLIB: ' + errText(e)); return null; }),
    ]);
    const y = yLrc && parseLrc(yLrc.text);
    if (y) return { synced: true, lines: y, writers: yLrc.writers, source: 'Яндекс Музыка' };
    const l = lib && lib.syncedLyrics && parseLrc(lib.syncedLyrics);
    if (l) return { synced: true, lines: l, writers: '', source: 'LRCLIB' };
    if (lib && lib.instrumental) return { none: true, instrumental: true, why: [] };
    const yTxt = await ya('TEXT').catch((e) => { why.push('Яндекс (текст): ' + errText(e)); return null; });
    const plain = (yTxt && yTxt.text.trim() && yTxt) || (lib && lib.plainLyrics && { text: lib.plainLyrics, writers: '' });
    if (plain) return { synced: false, lines: plain.text.split(/\r?\n/).map((text) => ({ t: -1, text: text.trim() })), writers: plain.writers, source: plain === yTxt ? 'Яндекс Музыка' : 'LRCLIB' };
    console.log('[lyrics]', id, why.join(' | '));
    return { none: true, why };
  },
  tokenProblem() { return tokenBad; },
};

// ---------- живые тексты: разбор LRC и открытая база LRCLIB (lrclib.net — без ключей и регистрации) ----------
const errText = (e) => (e && e.status ? 'ответ ' + e.status : '') + (e && e.message && !/^HTTP \d+$/.test(e.message) ? (e.status ? ', ' : '') + e.message : '');
function parseLrc(text) {
  if (!text || !/\[\d+:\d+/.test(text)) return null;
  const lines = [];
  for (const ln of String(text).split(/\r?\n/)) {
    const tags = [...ln.matchAll(/\[(\d+):(\d+(?:[.:]\d+)?)\]/g)]; if (!tags.length) continue;
    const t = ln.replace(/\[[^\]]*\]/g, '').trim();
    for (const m of tags) lines.push({ t: +m[1] * 60 + parseFloat(m[2].replace(':', '.')), text: t });
  }
  lines.sort((a, b) => a.t - b.t);
  return lines.length ? lines : null;
}
const LRCLIB_UA = 'Pulse Desktop (alpha; Windows music player)';
const bare = (s) => String(s || '').replace(/\s*[([].*?[)\]]\s*/g, ' ').replace(/\s+/g, ' ').trim();
async function lrclib({ title, artist, album, dur } = {}) {
  if (!title || !artist) throw new Error('нет названия');
  const get = async (q) => {
    const r = await fetch('https://lrclib.net/api/search?' + new URLSearchParams(q), { headers: { 'User-Agent': LRCLIB_UA }, signal: AbortSignal.timeout(10000) });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status });
    return r.json();
  };
  let list = await get({ track_name: title, artist_name: artist });
  if (!list.length && bare(title) !== title) list = await get({ track_name: bare(title), artist_name: artist });
  if (!list.length) list = await get({ q: bare(title) + ' ' + artist });
  if (!list.length) throw new Error('не нашлось');
  // ближе всего по длительности; среди близких — с живым текстом
  const d = (x) => (dur ? Math.abs((x.duration || 0) - dur) : 0);
  const ok = list.filter((x) => !dur || d(x) <= 4);
  const pool = ok.length ? ok : list;
  pool.sort((a, b) => (!!b.syncedLyrics - !!a.syncedLyrics) || (d(a) - d(b)));
  return pool[0];
}

module.exports = api;
